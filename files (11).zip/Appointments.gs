// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Appointments.gs
//  Phase       : 3 — Appointments Module
//  Version     : 1.2.0
//  Description : Full backend for appointment management.
//                Booking, conflict detection, schedule view,
//                status updates, and follow-up tracking.
//                All functions called via google.script.run
//                from ApptForm.html and ApptSchedule.html.
// ============================================================


// ════════════════════════════════════════════════════════════
//  SIDEBAR LAUNCHERS
// ════════════════════════════════════════════════════════════

/**
 * openNewAppointmentForm()
 * Opens the "Book Appointment" sidebar.
 */
function openNewAppointmentForm() {
  const html = HtmlService
    .createHtmlOutputFromFile('ApptForm')
    .setTitle('Book Appointment')
    .setWidth(440);

  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openNewAppointmentForm', 'Appointment booking sidebar opened.');
}

/**
 * openTodaySchedule()
 * Opens the "Today's Schedule" sidebar.
 */
function openTodaySchedule() {
  const html = HtmlService
    .createHtmlOutputFromFile('ApptSchedule')
    .setTitle("Today's Schedule")
    .setWidth(460);

  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openTodaySchedule', "Today's schedule sidebar opened.");
}

/**
 * openEditAppointmentForm(apptId)
 * Opens the Edit sidebar pre-filled for an existing appointment.
 * Called from ApptSchedule.html when user clicks "Edit".
 */
function openEditAppointmentForm(apptId) {
  const html      = HtmlService.createTemplateFromFile('ApptForm');
  html.editMode   = true;
  html.apptId     = apptId;

  const output = html.evaluate()
    .setTitle('Edit Appointment — ' + apptId)
    .setWidth(440);

  SpreadsheetApp.getUi().showSidebar(output);
  _log('INFO', 'openEditAppointmentForm', `Edit sidebar opened for: ${apptId}`);
}


// ════════════════════════════════════════════════════════════
//  BOOTSTRAP DATA  (called once on sidebar load)
// ════════════════════════════════════════════════════════════

/**
 * getApptBootstrap()
 * Returns everything the booking form needs in one round-trip:
 *   - clinic settings (branding)
 *   - active doctor list (from existing appointments, deduped)
 *   - generated time slots
 *   - today's date string
 */
function getApptBootstrap() {
  try {
    const s = getSettings();
    return {
      clinicName  : s['Clinic_Name']   || 'My Clinic',
      primaryColor: s['Primary_Color'] || '#1a73e8',
      currency    : s['Currency']      || '₹',
      timezone    : s['Timezone']      || 'Asia/Kolkata',
      todayIso    : _getTodayIso(),
      timeSlots   : _generateTimeSlots('08:00', '20:00', 15),
      doctors     : _getActiveDoctors()
    };
  } catch (err) {
    _log('ERROR', 'getApptBootstrap', err.message);
    return {};
  }
}

/**
 * getScheduleBootstrap()
 * Returns settings needed by the schedule sidebar.
 */
function getScheduleBootstrap() {
  try {
    const s = getSettings();
    return {
      clinicName  : s['Clinic_Name']   || 'My Clinic',
      primaryColor: s['Primary_Color'] || '#1a73e8',
      currency    : s['Currency']      || '₹',
      timezone    : s['Timezone']      || 'Asia/Kolkata',
      todayIso    : _getTodayIso(),
      todayDisplay: _getTodayDisplay()
    };
  } catch (err) {
    _log('ERROR', 'getScheduleBootstrap', err.message);
    return {};
  }
}


// ════════════════════════════════════════════════════════════
//  PATIENT LOOKUP  (for the patient search-as-you-type)
// ════════════════════════════════════════════════════════════

/**
 * searchPatientsForAppt(query)
 * Lightweight patient search for the appointment form's
 * patient selector. Returns only Active patients.
 *
 * @param  {string} query
 * @returns {Object[]}
 */
function searchPatientsForAppt(query) {
  try {
    const term = String(query || '').trim().toLowerCase();
    if (term.length < 2) return [];

    const all = getSheetData(SHEET_NAMES.KYC);

    return all
      .filter(p =>
        p['Status'] === 'Active' &&
        (
          String(p['Patient_ID'] || '').toLowerCase().includes(term) ||
          String(p['Full_Name']  || '').toLowerCase().includes(term) ||
          String(p['Phone']      || '').toLowerCase().includes(term)
        )
      )
      .slice(-20)          // most-recently added first
      .reverse()
      .map(p => ({
        patientId: p['Patient_ID'],
        fullName : p['Full_Name'],
        phone    : p['Phone'],
        age      : p['Age']
      }));

  } catch (err) {
    _log('ERROR', 'searchPatientsForAppt', err.message);
    return [];
  }
}


// ════════════════════════════════════════════════════════════
//  CONFLICT DETECTION
// ════════════════════════════════════════════════════════════

/**
 * checkConflict(doctor, apptDate, timeSlot, excludeApptId)
 * ─────────────────────────────────────────────────────────────
 * Returns true if the given doctor already has a Scheduled or
 * Rescheduled appointment at the exact date + time slot.
 * Pass excludeApptId when editing to skip the record itself.
 *
 * @param  {string} doctor
 * @param  {string} apptDate      ISO date string "YYYY-MM-DD"
 * @param  {string} timeSlot      e.g. "10:00 AM"
 * @param  {string} excludeApptId optional — apptId to skip
 * @returns {{ conflict: boolean, existingAppt?: Object }}
 */
function checkConflict(doctor, apptDate, timeSlot, excludeApptId) {
  try {
    const all = getSheetData(SHEET_NAMES.APPOINTMENTS);

    const conflicting = all.find(a => {
      if (excludeApptId && a['Appt_ID'] === excludeApptId) return false;

      const statusBlocks = ['Scheduled', 'Rescheduled'];
      if (!statusBlocks.includes(a['Status'])) return false;

      const sameDoctor = String(a['Doctor']    || '').trim().toLowerCase()
                      === String(doctor         || '').trim().toLowerCase();
      const sameDate   = _normalizeDate(a['Appt_Date']) === apptDate;
      const sameSlot   = String(a['Time_Slot'] || '').trim() === String(timeSlot || '').trim();

      return sameDoctor && sameDate && sameSlot;
    });

    if (conflicting) {
      return {
        conflict    : true,
        existingAppt: {
          apptId     : conflicting['Appt_ID'],
          patientName: conflicting['Patient_Name'],
          timeSlot   : conflicting['Time_Slot']
        }
      };
    }

    return { conflict: false };

  } catch (err) {
    _log('ERROR', 'checkConflict', err.message);
    return { conflict: false };  // fail open — don't block the booking
  }
}


// ════════════════════════════════════════════════════════════
//  CORE CRUD
// ════════════════════════════════════════════════════════════

/**
 * bookAppointment(formData)
 * ─────────────────────────────────────────────────────────────
 * Validates, conflict-checks, and saves a new appointment.
 *
 * @param  {Object} formData
 * @returns {{ success, apptId, message }}
 */
function bookAppointment(formData) {
  try {
    // 1. Required field validation
    const validation = validateRequiredFields(formData, [
      'patientId', 'doctor', 'apptDate', 'timeSlot', 'apptType'
    ]);
    if (!validation.valid) {
      return { success: false, message: 'Please fill in: ' + validation.missing.join(', ') };
    }

    // 2. Verify patient exists and is Active
    const patient = _getPatientRecord(formData.patientId);
    if (!patient) {
      return { success: false, message: `Patient ID "${formData.patientId}" not found.` };
    }
    if (patient['Status'] !== 'Active') {
      return { success: false, message: `Patient ${formData.patientId} is marked Inactive. Reactivate them first.` };
    }

    // 3. Conflict detection
    const conflict = checkConflict(
      formData.doctor,
      formData.apptDate,
      formData.timeSlot
    );
    if (conflict.conflict) {
      return {
        success : false,
        conflict: true,
        message : `Dr. ${formData.doctor} already has ${conflict.existingAppt.patientName} booked at ${conflict.existingAppt.timeSlot} on this date.`
      };
    }

    // 4. Generate ID and timestamps
    const apptId = generateUniqueId('Appt_ID_Prefix', 'Last_Appt_Seq');
    const now    = getTimestamp();

    // 5. Build row — exact column order A→O
    const row = [
      apptId,                                        // A  Appt_ID
      formData.patientId,                            // B  Patient_ID
      patient['Full_Name'],                          // C  Patient_Name (auto-filled)
      sanitizeText(formData.doctor),                 // D  Doctor
      formData.apptDate,                             // E  Appt_Date
      formData.timeSlot,                             // F  Time_Slot
      formData.apptType,                             // G  Appt_Type
      'Scheduled',                                   // H  Status (always starts Scheduled)
      '',                                            // I  Diagnosis (filled post-visit)
      '',                                            // J  Prescription (filled post-visit)
      sanitizeNumber(formData.consultationFee, 0),   // K  Consultation_Fee
      sanitizeText(formData.notes || ''),            // L  Notes
      formData.followUpDate || '',                   // M  Follow_Up_Date
      now,                                           // N  Created_At
      now                                            // O  Updated_At
    ];

    appendRowToSheet(SHEET_NAMES.APPOINTMENTS, row);
    _highlightNewRow(SHEET_NAMES.APPOINTMENTS);

    _log('INFO', 'bookAppointment',
      `Booked: ${apptId} — ${patient['Full_Name']} with Dr. ${formData.doctor} on ${formData.apptDate} ${formData.timeSlot}`);

    return {
      success: true,
      apptId,
      message: `Appointment booked!\nID: ${apptId}\nPatient: ${patient['Full_Name']}`
    };

  } catch (err) {
    _log('ERROR', 'bookAppointment', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


/**
 * getAppointmentById(apptId)
 * Returns the full appointment record for edit pre-fill.
 *
 * @param  {string} apptId
 * @returns {Object|null}
 */
function getAppointmentById(apptId) {
  try {
    const all  = getSheetData(SHEET_NAMES.APPOINTMENTS);
    const appt = all.find(a => a['Appt_ID'] === apptId);
    if (!appt) return null;

    return {
      apptId         : appt['Appt_ID'],
      patientId      : appt['Patient_ID'],
      patientName    : appt['Patient_Name'],
      doctor         : appt['Doctor'],
      apptDate       : _normalizeDate(appt['Appt_Date']),
      timeSlot       : appt['Time_Slot'],
      apptType       : appt['Appt_Type'],
      status         : appt['Status'],
      diagnosis      : appt['Diagnosis'],
      prescription   : appt['Prescription'],
      consultationFee: appt['Consultation_Fee'],
      notes          : appt['Notes'],
      followUpDate   : _normalizeDate(appt['Follow_Up_Date']),
      createdAt      : appt['Created_At'],
      updatedAt      : appt['Updated_At']
    };
  } catch (err) {
    _log('ERROR', 'getAppointmentById', err.message);
    return null;
  }
}


/**
 * updateAppointment(apptId, formData)
 * ─────────────────────────────────────────────────────────────
 * Updates all editable fields on an existing appointment.
 * Appt_ID, Patient_ID, Patient_Name, and Created_At are immutable.
 * Runs conflict check, skipping the appointment itself.
 *
 * @param  {string} apptId
 * @param  {Object} formData
 * @returns {{ success, message }}
 */
function updateAppointment(apptId, formData) {
  try {
    const validation = validateRequiredFields(formData, [
      'patientId', 'doctor', 'apptDate', 'timeSlot', 'apptType'
    ]);
    if (!validation.valid) {
      return { success: false, message: 'Please fill in: ' + validation.missing.join(', ') };
    }

    // Conflict check — exclude this appointment itself
    const conflict = checkConflict(
      formData.doctor,
      formData.apptDate,
      formData.timeSlot,
      apptId
    );
    if (conflict.conflict) {
      return {
        success : false,
        conflict: true,
        message : `Dr. ${formData.doctor} already has ${conflict.existingAppt.patientName} booked at ${conflict.existingAppt.timeSlot} on this date.`
      };
    }

    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.APPOINTMENTS);
    const data  = sheet.getDataRange().getValues();

    let targetRow = -1;
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === apptId) { targetRow = i + 1; break; }
    }
    if (targetRow === -1) {
      return { success: false, message: `Appointment ${apptId} not found.` };
    }

    const now = getTimestamp();

    // Write editable columns (B is Patient_ID — keep; C is Patient_Name — keep)
    // D=4, E=5, F=6, G=7, H=8, I=9, J=10, K=11, L=12, M=13, O=15
    const edits = {
      4 : sanitizeText(formData.doctor),
      5 : formData.apptDate,
      6 : formData.timeSlot,
      7 : formData.apptType,
      8 : formData.status         || 'Scheduled',
      9 : sanitizeText(formData.diagnosis     || ''),
      10: sanitizeText(formData.prescription  || ''),
      11: sanitizeNumber(formData.consultationFee, 0),
      12: sanitizeText(formData.notes         || ''),
      13: formData.followUpDate   || '',
      15: now   // Updated_At
    };

    Object.entries(edits).forEach(([col, val]) => {
      sheet.getRange(targetRow, Number(col)).setValue(val);
    });

    _log('INFO', 'updateAppointment', `Updated: ${apptId}`);
    return { success: true, message: `Appointment ${apptId} updated successfully.` };

  } catch (err) {
    _log('ERROR', 'updateAppointment', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


/**
 * updateAppointmentStatus(apptId, newStatus, diagnosis, prescription)
 * ─────────────────────────────────────────────────────────────
 * Quick-status update called directly from the schedule view.
 * Only touches Status, Diagnosis, Prescription, Updated_At.
 * Does not require full form submission.
 *
 * @param  {string} apptId
 * @param  {string} newStatus      Scheduled|Completed|Cancelled|No-Show|Rescheduled
 * @param  {string} diagnosis      optional — filled when marking Completed
 * @param  {string} prescription   optional
 * @returns {{ success, message }}
 */
function updateAppointmentStatus(apptId, newStatus, diagnosis, prescription) {
  try {
    const VALID_STATUSES = ['Scheduled', 'Completed', 'Cancelled', 'No-Show', 'Rescheduled'];
    if (!VALID_STATUSES.includes(newStatus)) {
      return { success: false, message: `Invalid status: ${newStatus}` };
    }

    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.APPOINTMENTS);
    const data  = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === apptId) {
        const row = i + 1;
        sheet.getRange(row, 8).setValue(newStatus);           // H Status
        if (diagnosis)    sheet.getRange(row, 9).setValue(sanitizeText(diagnosis));
        if (prescription) sheet.getRange(row, 10).setValue(sanitizeText(prescription));
        sheet.getRange(row, 15).setValue(getTimestamp());     // O Updated_At

        _log('INFO', 'updateAppointmentStatus', `${apptId} → ${newStatus}`);
        return { success: true, message: `Status updated to ${newStatus}.` };
      }
    }

    return { success: false, message: `Appointment ${apptId} not found.` };

  } catch (err) {
    _log('ERROR', 'updateAppointmentStatus', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


// ════════════════════════════════════════════════════════════
//  SCHEDULE VIEWS
// ════════════════════════════════════════════════════════════

/**
 * getScheduleForDate(dateIso)
 * ─────────────────────────────────────────────────────────────
 * Returns all appointments for a given date, sorted by time slot.
 * Used by ApptSchedule.html to render the day view.
 *
 * @param  {string} dateIso  "YYYY-MM-DD"
 * @returns {Object[]}
 */
function getScheduleForDate(dateIso) {
  try {
    const all = getSheetData(SHEET_NAMES.APPOINTMENTS);

    const dayAppts = all.filter(a => _normalizeDate(a['Appt_Date']) === dateIso);

    // Sort by time slot (convert "10:00 AM" → 24h number for sorting)
    dayAppts.sort((a, b) => _timeSlotToMinutes(a['Time_Slot']) - _timeSlotToMinutes(b['Time_Slot']));

    return dayAppts.map(a => ({
      apptId         : a['Appt_ID'],
      patientId      : a['Patient_ID'],
      patientName    : a['Patient_Name'],
      doctor         : a['Doctor'],
      apptDate       : _normalizeDate(a['Appt_Date']),
      timeSlot       : a['Time_Slot'],
      apptType       : a['Appt_Type'],
      status         : a['Status'],
      diagnosis      : a['Diagnosis'],
      prescription   : a['Prescription'],
      consultationFee: a['Consultation_Fee'],
      notes          : a['Notes'],
      followUpDate   : _normalizeDate(a['Follow_Up_Date'])
    }));

  } catch (err) {
    _log('ERROR', 'getScheduleForDate', err.message);
    return [];
  }
}


/**
 * getApptStats()
 * ─────────────────────────────────────────────────────────────
 * Dashboard numbers shown at the top of the schedule sidebar.
 * @returns {{ todayTotal, todayCompleted, todayPending, thisMonth }}
 */
function getApptStats() {
  try {
    const all      = getSheetData(SHEET_NAMES.APPOINTMENTS);
    const tz       = getSetting('Timezone') || 'Asia/Kolkata';
    const todayIso = _getTodayIso();
    const monthStr = Utilities.formatDate(new Date(), tz, 'yyyy-MM');

    const todayAppts = all.filter(a => _normalizeDate(a['Appt_Date']) === todayIso);

    return {
      todayTotal    : todayAppts.length,
      todayCompleted: todayAppts.filter(a => a['Status'] === 'Completed').length,
      todayPending  : todayAppts.filter(a => ['Scheduled', 'Rescheduled'].includes(a['Status'])).length,
      thisMonth     : all.filter(a => (_normalizeDate(a['Appt_Date']) || '').startsWith(monthStr)).length
    };
  } catch (err) {
    _log('ERROR', 'getApptStats', err.message);
    return { todayTotal: 0, todayCompleted: 0, todayPending: 0, thisMonth: 0 };
  }
}


/**
 * getSlotsForDoctor(doctor, dateIso)
 * ─────────────────────────────────────────────────────────────
 * Returns which time slots are already booked for a doctor
 * on a given date. Used by the booking form to mark slots busy.
 *
 * @param  {string} doctor
 * @param  {string} dateIso
 * @returns {string[]} Array of booked time slot strings
 */
function getSlotsForDoctor(doctor, dateIso) {
  try {
    const all = getSheetData(SHEET_NAMES.APPOINTMENTS);

    return all
      .filter(a =>
        String(a['Doctor'] || '').trim().toLowerCase() === doctor.trim().toLowerCase() &&
        _normalizeDate(a['Appt_Date']) === dateIso &&
        ['Scheduled', 'Rescheduled'].includes(a['Status'])
      )
      .map(a => String(a['Time_Slot']).trim());

  } catch (err) {
    _log('ERROR', 'getSlotsForDoctor', err.message);
    return [];
  }
}


/**
 * navigateToApptRow(apptId)
 * Scrolls the sheet to the appointment's row.
 */
function navigateToApptRow(apptId) {
  try {
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.APPOINTMENTS);
    const data  = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === apptId) {
        ss.setActiveSheet(sheet);
        sheet.setActiveRange(sheet.getRange(i + 1, 1));
        SpreadsheetApp.flush();
        return;
      }
    }
  } catch (err) {
    _log('ERROR', 'navigateToApptRow', err.message);
  }
}


// ════════════════════════════════════════════════════════════
//  PRIVATE HELPERS
// ════════════════════════════════════════════════════════════

/**
 * _getPatientRecord(patientId)
 * Returns the raw KYC row object for a patient ID.
 */
function _getPatientRecord(patientId) {
  const all = getSheetData(SHEET_NAMES.KYC);
  return all.find(p => p['Patient_ID'] === patientId) || null;
}

/**
 * _normalizeDate(value)
 * Converts any date value (Date object, "DD/MM/YYYY", "YYYY-MM-DD")
 * to a consistent "YYYY-MM-DD" ISO string for comparisons.
 */
function _normalizeDate(value) {
  if (!value) return '';

  try {
    if (value instanceof Date) {
      return Utilities.formatDate(value, 'UTC', 'yyyy-MM-dd');
    }
    const str = String(value).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;

    // DD/MM/YYYY
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(str)) {
      const [d, m, y] = str.split('/');
      return `${y}-${m}-${d}`;
    }
    // Try generic parse
    const parsed = new Date(str);
    if (!isNaN(parsed)) return Utilities.formatDate(parsed, 'UTC', 'yyyy-MM-dd');

    return '';
  } catch (e) {
    return '';
  }
}

/**
 * _getTodayIso()
 * Returns today's date as "YYYY-MM-DD" in the clinic's timezone.
 */
function _getTodayIso() {
  const tz = getSetting('Timezone') || 'Asia/Kolkata';
  return Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');
}

/**
 * _getTodayDisplay()
 * Returns today's date formatted for display, e.g. "Wednesday, 1 Jan 2025"
 */
function _getTodayDisplay() {
  const tz = getSetting('Timezone') || 'Asia/Kolkata';
  return Utilities.formatDate(new Date(), tz, 'EEEE, d MMM yyyy');
}

/**
 * _generateTimeSlots(startTime, endTime, intervalMinutes)
 * Generates an array of time slot strings between start and end.
 * e.g. ["08:00 AM", "08:15 AM", ..., "08:00 PM"]
 *
 * @param {string} startTime  "HH:MM" 24h
 * @param {string} endTime    "HH:MM" 24h
 * @param {number} intervalMinutes
 * @returns {string[]}
 */
function _generateTimeSlots(startTime, endTime, intervalMinutes) {
  const slots = [];
  let [sh, sm] = startTime.split(':').map(Number);
  const [eh, em] = endTime.split(':').map(Number);
  const endMins = eh * 60 + em;

  while (sh * 60 + sm < endMins) {
    const h12 = sh % 12 || 12;
    const ampm = sh < 12 ? 'AM' : 'PM';
    slots.push(`${String(h12).padStart(2, '0')}:${String(sm).padStart(2, '0')} ${ampm}`);
    sm += intervalMinutes;
    if (sm >= 60) { sh += Math.floor(sm / 60); sm = sm % 60; }
  }

  return slots;
}

/**
 * _timeSlotToMinutes(slot)
 * Converts "10:30 AM" → 630, "01:00 PM" → 780 for sorting.
 */
function _timeSlotToMinutes(slot) {
  if (!slot) return 9999;
  const match = String(slot).match(/(\d+):(\d+)\s*(AM|PM)/i);
  if (!match) return 9999;
  let h = parseInt(match[1]);
  const m = parseInt(match[2]);
  const ampm = match[3].toUpperCase();
  if (ampm === 'PM' && h !== 12) h += 12;
  if (ampm === 'AM' && h === 12) h = 0;
  return h * 60 + m;
}

/**
 * _getActiveDoctors()
 * Returns a deduped, sorted list of doctor names from existing
 * appointments. Gives the form a dropdown of known doctors.
 */
function _getActiveDoctors() {
  try {
    const all     = getSheetData(SHEET_NAMES.APPOINTMENTS);
    const doctors = [...new Set(
      all
        .map(a => sanitizeText(String(a['Doctor'] || '')))
        .filter(Boolean)
    )].sort();
    return doctors;
  } catch (e) {
    return [];
  }
}

/**
 * _highlightNewRow(sheetName)
 * Briefly flashes the last row light green on save.
 */
function _highlightNewApptRow() {
  try {
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.APPOINTMENTS);
    const last  = sheet.getLastRow();
    if (last < 2) return;
    const range = sheet.getRange(last, 1, 1, sheet.getLastColumn());
    range.setBackground('#c8e6c9');
    SpreadsheetApp.flush();
    Utilities.sleep(700);
    range.setBackground(null);
  } catch (e) { /* non-critical */ }
}
