// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Finance.gs
//  Phase       : 4 — Sales & Expenses Module
//  Version     : 1.3.0
//  Description : Full backend for sales recording, expense
//                tracking, and profit calculation.
//                All functions called via google.script.run
//                from FinanceSale.html and FinanceExpense.html.
// ============================================================


// ════════════════════════════════════════════════════════════
//  SIDEBAR LAUNCHERS
// ════════════════════════════════════════════════════════════

function openSaleForm() {
  const html = HtmlService
    .createHtmlOutputFromFile('FinanceSale')
    .setTitle('Record Sale / Invoice')
    .setWidth(460);
  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openSaleForm', 'Sale form sidebar opened.');
}

function openExpenseForm() {
  const html = HtmlService
    .createHtmlOutputFromFile('FinanceExpense')
    .setTitle('Record Expense')
    .setWidth(440);
  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openExpenseForm', 'Expense form sidebar opened.');
}

function openFinanceSummary() {
  const html = HtmlService
    .createHtmlOutputFromFile('FinanceSummary')
    .setTitle('Finance Summary')
    .setWidth(460);
  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openFinanceSummary', 'Finance summary sidebar opened.');
}


// ════════════════════════════════════════════════════════════
//  BOOTSTRAP  (one round-trip on sidebar load)
// ════════════════════════════════════════════════════════════

/**
 * getFinanceBootstrap()
 * Everything both finance sidebars need on load.
 */
function getFinanceBootstrap() {
  try {
    const s = getSettings();
    return {
      clinicName  : s['Clinic_Name']   || 'My Clinic',
      primaryColor: s['Primary_Color'] || '#1a73e8',
      currency    : s['Currency']      || '₹',
      timezone    : s['Timezone']      || 'Asia/Kolkata',
      todayIso    : _finToday()
    };
  } catch (err) {
    _log('ERROR', 'getFinanceBootstrap', err.message);
    return {};
  }
}

/**
 * searchPatientsForFinance(query)
 * Lightweight patient search for sale form patient selector.
 * Same pattern as KYC and Appointments modules.
 */
function searchPatientsForFinance(query) {
  try {
    const term = String(query || '').trim().toLowerCase();
    if (term.length < 2) return [];

    return getSheetData(SHEET_NAMES.KYC)
      .filter(p =>
        p['Status'] === 'Active' &&
        (
          String(p['Patient_ID'] || '').toLowerCase().includes(term) ||
          String(p['Full_Name']  || '').toLowerCase().includes(term) ||
          String(p['Phone']      || '').toLowerCase().includes(term)
        )
      )
      .reverse()
      .slice(0, 15)
      .map(p => ({
        patientId: p['Patient_ID'],
        fullName : p['Full_Name'],
        phone    : p['Phone']
      }));
  } catch (err) {
    _log('ERROR', 'searchPatientsForFinance', err.message);
    return [];
  }
}


// ════════════════════════════════════════════════════════════
//  SALES MODULE
// ════════════════════════════════════════════════════════════

/**
 * recordSale(formData)
 * ─────────────────────────────────────────────────────────────
 * Validates and saves a new sale record.
 * Discount and Total are calculated server-side for accuracy —
 * never trust the browser's computed values.
 *
 * Sheet columns (A→P):
 * Sale_ID | Sale_Date | Patient_ID | Patient_Name | Item_Type |
 * Item_Name | Quantity | Unit_Price | Discount_Pct | Discount_Amt |
 * Total_Amount | Payment_Mode | Payment_Status | Invoice_No |
 * Notes | Created_At
 *
 * @param  {Object} formData
 * @returns {{ success, saleId, message }}
 */
function recordSale(formData) {
  try {
    // 1. Validate required fields
    const v = validateRequiredFields(formData, [
      'itemType', 'itemName', 'quantity', 'unitPrice', 'paymentMode'
    ]);
    if (!v.valid) {
      return { success: false, message: 'Please fill in: ' + v.missing.join(', ') };
    }

    // 2. Sanitize numbers — server-side calculation only
    const qty         = sanitizeNumber(formData.quantity,    1);
    const unitPrice   = sanitizeNumber(formData.unitPrice,   0);
    const discountPct = sanitizeNumber(formData.discountPct, 0);

    if (qty <= 0)       return { success: false, message: 'Quantity must be greater than 0.' };
    if (unitPrice <= 0) return { success: false, message: 'Unit price must be greater than 0.' };
    if (discountPct < 0 || discountPct > 100) {
      return { success: false, message: 'Discount must be between 0 and 100.' };
    }

    // 3. Calculate discount and total server-side
    const discountAmt  = parseFloat((qty * unitPrice * discountPct / 100).toFixed(2));
    const totalAmount  = parseFloat((qty * unitPrice - discountAmt).toFixed(2));

    // 4. Read settings once for ID + timezone
    const settings  = getSettings();
    const tz        = settings['Timezone'] || 'Asia/Kolkata';
    const now       = Utilities.formatDate(new Date(), tz, 'dd/MM/yyyy HH:mm:ss');
    const saleDate  = formData.saleDate || Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');

    // 5. Resolve patient name (if linked to a patient)
    let patientId   = sanitizeText(formData.patientId   || '');
    let patientName = sanitizeText(formData.patientName || '');

    if (patientId && !patientName) {
      const patient = _getPatientRecord(patientId);
      patientName   = patient ? patient['Full_Name'] : '';
    }

    // 6. Generate Sale ID
    const saleId = generateUniqueId('Sale_ID_Prefix', 'Last_Sale_Seq');

    // 7. Generate Invoice number
    const invoiceNo = formData.invoiceNo
      ? sanitizeText(formData.invoiceNo)
      : 'INV-' + saleId.replace('SAL-', '');

    // 8. Build row — exact column order A→P
    const row = [
      saleId,                                     // A Sale_ID
      saleDate,                                   // B Sale_Date
      patientId,                                  // C Patient_ID
      patientName,                                // D Patient_Name
      sanitizeText(formData.itemType),            // E Item_Type
      sanitizeText(formData.itemName),            // F Item_Name
      qty,                                        // G Quantity
      unitPrice,                                  // H Unit_Price
      discountPct,                                // I Discount_Pct
      discountAmt,                                // J Discount_Amt
      totalAmount,                                // K Total_Amount
      sanitizeText(formData.paymentMode),         // L Payment_Mode
      sanitizeText(formData.paymentStatus || 'Paid'), // M Payment_Status
      invoiceNo,                                  // N Invoice_No
      sanitizeText(formData.notes || ''),         // O Notes
      now                                         // P Created_At
    ];

    appendRowToSheet(SHEET_NAMES.SALES, row);

    _log('INFO', 'recordSale',
      `Sale recorded: ${saleId} — ${formData.itemName} — ₹${totalAmount}`);

    return {
      success    : true,
      saleId     : saleId,
      totalAmount: totalAmount,
      invoiceNo  : invoiceNo,
      message    : `Sale saved!\nID: ${saleId}\nTotal: ₹${totalAmount}`
    };

  } catch (err) {
    _log('ERROR', 'recordSale', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}

/**
 * getSaleStats()
 * Returns headline numbers for the sale form stats bar.
 * @returns {{ todayRevenue, todayCount, monthRevenue, monthCount }}
 */
function getSaleStats() {
  try {
    const all      = getSheetData(SHEET_NAMES.SALES);
    const tz       = getSetting('Timezone') || 'Asia/Kolkata';
    const todayIso = _finToday();
    const monthStr = Utilities.formatDate(new Date(), tz, 'yyyy-MM');

    const todaySales = all.filter(s => {
      const d = String(s['Sale_Date'] || '');
      return d === todayIso || d.startsWith(todayIso);
    });

    const monthSales = all.filter(s =>
      String(s['Sale_Date'] || '').startsWith(monthStr)
    );

    return {
      todayRevenue : _sumField(todaySales,  'Total_Amount'),
      todayCount   : todaySales.length,
      monthRevenue : _sumField(monthSales,  'Total_Amount'),
      monthCount   : monthSales.length
    };
  } catch (err) {
    _log('ERROR', 'getSaleStats', err.message);
    return { todayRevenue: 0, todayCount: 0, monthRevenue: 0, monthCount: 0 };
  }
}

/**
 * getRecentSales(limit)
 * Returns the most recent sales for the sidebar list.
 * @param  {number} limit - max rows to return (default 15)
 */
function getRecentSales(limit) {
  try {
    const all = getSheetData(SHEET_NAMES.SALES);
    return all
      .reverse()
      .slice(0, limit || 15)
      .map(s => ({
        saleId      : s['Sale_ID'],
        saleDate    : s['Sale_Date'],
        patientName : s['Patient_Name']  || 'Walk-in',
        itemName    : s['Item_Name'],
        totalAmount : s['Total_Amount'],
        paymentMode : s['Payment_Mode'],
        paymentStatus:s['Payment_Status'],
        invoiceNo   : s['Invoice_No']
      }));
  } catch (err) {
    _log('ERROR', 'getRecentSales', err.message);
    return [];
  }
}

/**
 * updateSaleStatus(saleId, newStatus)
 * Quick payment status update from the sales list.
 */
function updateSaleStatus(saleId, newStatus) {
  try {
    const VALID = ['Paid', 'Pending', 'Partial', 'Refunded'];
    if (!VALID.includes(newStatus)) {
      return { success: false, message: 'Invalid status: ' + newStatus };
    }

    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.SALES);
    const data  = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === saleId) {
        sheet.getRange(i + 1, 13).setValue(newStatus); // M = Payment_Status
        _log('INFO', 'updateSaleStatus', `${saleId} → ${newStatus}`);
        return { success: true, message: `Payment status updated to ${newStatus}.` };
      }
    }
    return { success: false, message: `Sale ${saleId} not found.` };
  } catch (err) {
    _log('ERROR', 'updateSaleStatus', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


// ════════════════════════════════════════════════════════════
//  EXPENSES MODULE
// ════════════════════════════════════════════════════════════

/**
 * recordExpense(formData)
 * ─────────────────────────────────────────────────────────────
 * Validates and saves a new expense record.
 *
 * Sheet columns (A→N):
 * Expense_ID | Expense_Date | Category | Sub_Category |
 * Description | Amount | Paid_To | Payment_Mode |
 * Receipt_No | Approved_By | Is_Recurring | Recur_Period |
 * Notes | Created_At
 *
 * @param  {Object} formData
 * @returns {{ success, expenseId, message }}
 */
function recordExpense(formData) {
  try {
    // 1. Required fields
    const v = validateRequiredFields(formData, [
      'category', 'description', 'amount', 'paymentMode'
    ]);
    if (!v.valid) {
      return { success: false, message: 'Please fill in: ' + v.missing.join(', ') };
    }

    // 2. Amount validation
    const amount = sanitizeNumber(formData.amount, 0);
    if (amount <= 0) {
      return { success: false, message: 'Amount must be greater than 0.' };
    }

    // 3. Settings + timestamp
    const settings     = getSettings();
    const tz           = settings['Timezone'] || 'Asia/Kolkata';
    const now          = Utilities.formatDate(new Date(), tz, 'dd/MM/yyyy HH:mm:ss');
    const expenseDate  = formData.expenseDate || Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');

    // 4. Generate Expense ID
    const expenseId = generateUniqueId('Expense_ID_Prefix', 'Last_Expense_Seq');

    // 5. Build row — exact column order A→N
    const row = [
      expenseId,                                          // A Expense_ID
      expenseDate,                                        // B Expense_Date
      sanitizeText(formData.category),                   // C Category
      sanitizeText(formData.subCategory    || ''),       // D Sub_Category
      sanitizeText(formData.description),                // E Description
      amount,                                            // F Amount
      sanitizeText(formData.paidTo         || ''),       // G Paid_To
      sanitizeText(formData.paymentMode),                // H Payment_Mode
      sanitizeText(formData.receiptNo      || ''),       // I Receipt_No
      sanitizeText(formData.approvedBy     || ''),       // J Approved_By
      formData.isRecurring === 'Yes' ? 'Yes' : 'No',    // K Is_Recurring
      sanitizeText(formData.recurPeriod    || ''),       // L Recur_Period
      sanitizeText(formData.notes          || ''),       // M Notes
      now                                                // N Created_At
    ];

    appendRowToSheet(SHEET_NAMES.EXPENSES, row);

    _log('INFO', 'recordExpense',
      `Expense recorded: ${expenseId} — ${formData.description} — ₹${amount}`);

    return {
      success  : true,
      expenseId: expenseId,
      amount   : amount,
      message  : `Expense saved!\nID: ${expenseId}\nAmount: ₹${amount}`
    };

  } catch (err) {
    _log('ERROR', 'recordExpense', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}

/**
 * getExpenseStats()
 * Returns headline numbers for the expense form stats bar.
 */
function getExpenseStats() {
  try {
    const all      = getSheetData(SHEET_NAMES.EXPENSES);
    const tz       = getSetting('Timezone') || 'Asia/Kolkata';
    const todayIso = _finToday();
    const monthStr = Utilities.formatDate(new Date(), tz, 'yyyy-MM');

    const todayExp = all.filter(e =>
      String(e['Expense_Date'] || '').startsWith(todayIso) ||
      String(e['Expense_Date'] || '') === todayIso
    );
    const monthExp = all.filter(e =>
      String(e['Expense_Date'] || '').startsWith(monthStr)
    );

    // Category breakdown for this month
    const byCategory = {};
    monthExp.forEach(e => {
      const cat = e['Category'] || 'Other';
      byCategory[cat] = (byCategory[cat] || 0) + sanitizeNumber(e['Amount'], 0);
    });

    return {
      todayExpense : _sumField(todayExp, 'Amount'),
      todayCount   : todayExp.length,
      monthExpense : _sumField(monthExp, 'Amount'),
      monthCount   : monthExp.length,
      byCategory   : byCategory
    };
  } catch (err) {
    _log('ERROR', 'getExpenseStats', err.message);
    return { todayExpense: 0, todayCount: 0, monthExpense: 0, monthCount: 0, byCategory: {} };
  }
}

/**
 * getRecentExpenses(limit)
 * Returns the most recent expenses for the sidebar list.
 */
function getRecentExpenses(limit) {
  try {
    const all = getSheetData(SHEET_NAMES.EXPENSES);
    return all
      .reverse()
      .slice(0, limit || 15)
      .map(e => ({
        expenseId  : e['Expense_ID'],
        expenseDate: e['Expense_Date'],
        category   : e['Category'],
        description: e['Description'],
        amount     : e['Amount'],
        paidTo     : e['Paid_To'],
        paymentMode: e['Payment_Mode'],
        isRecurring: e['Is_Recurring']
      }));
  } catch (err) {
    _log('ERROR', 'getRecentExpenses', err.message);
    return [];
  }
}


// ════════════════════════════════════════════════════════════
//  PROFIT CALCULATOR
// ════════════════════════════════════════════════════════════

/**
 * calculateProfit(period)
 * ─────────────────────────────────────────────────────────────
 * Computes P&L for a given period.
 * period: 'today' | 'week' | 'month' | 'year'
 *
 * Called from the Finance Summary sidebar and from the menu.
 *
 * @param  {string} period
 * @returns {{ revenue, expenses, grossProfit, margin, period, byCategory }}
 */
function calculateProfit(period) {
  try {
    period = period || 'month';

    const tz  = getSetting('Timezone') || 'Asia/Kolkata';
    const now = new Date();

    // Determine date range
    const { startIso, endIso, label } = _getPeriodRange(period, now, tz);

    // Filter sales and expenses within range
    const allSales    = getSheetData(SHEET_NAMES.SALES);
    const allExpenses = getSheetData(SHEET_NAMES.EXPENSES);

    const periodSales = allSales.filter(s => {
      const d = String(s['Sale_Date'] || '').slice(0, 10);
      return d >= startIso && d <= endIso;
    });

    const periodExpenses = allExpenses.filter(e => {
      const d = String(e['Expense_Date'] || '').slice(0, 10);
      return d >= startIso && d <= endIso;
    });

    // Totals
    const revenue     = parseFloat(_sumField(periodSales,    'Total_Amount').toFixed(2));
    const expenses    = parseFloat(_sumField(periodExpenses, 'Amount').toFixed(2));
    const grossProfit = parseFloat((revenue - expenses).toFixed(2));
    const margin      = revenue > 0
      ? parseFloat(((grossProfit / revenue) * 100).toFixed(1))
      : 0;

    // Revenue by item type
    const revenueByType = {};
    periodSales.forEach(s => {
      const t = s['Item_Type'] || 'Other';
      revenueByType[t] = (revenueByType[t] || 0) + sanitizeNumber(s['Total_Amount'], 0);
    });

    // Expense by category
    const expenseByCategory = {};
    periodExpenses.forEach(e => {
      const c = e['Category'] || 'Other';
      expenseByCategory[c] = (expenseByCategory[c] || 0) + sanitizeNumber(e['Amount'], 0);
    });

    // Payment mode breakdown
    const byPaymentMode = {};
    periodSales.forEach(s => {
      const m = s['Payment_Mode'] || 'Other';
      byPaymentMode[m] = (byPaymentMode[m] || 0) + sanitizeNumber(s['Total_Amount'], 0);
    });

    _log('INFO', 'calculateProfit',
      `Period: ${label} | Revenue: ${revenue} | Expenses: ${expenses} | Profit: ${grossProfit}`);

    return {
      success            : true,
      period             : label,
      startDate          : startIso,
      endDate            : endIso,
      revenue            : revenue,
      expenses           : expenses,
      grossProfit        : grossProfit,
      margin             : margin,
      saleCount          : periodSales.length,
      expenseCount       : periodExpenses.length,
      revenueByType      : revenueByType,
      expenseByCategory  : expenseByCategory,
      byPaymentMode      : byPaymentMode
    };

  } catch (err) {
    _log('ERROR', 'calculateProfit', err.message);
    return { success: false, message: err.message };
  }
}


// ════════════════════════════════════════════════════════════
//  PRIVATE HELPERS
// ════════════════════════════════════════════════════════════

/**
 * _getPatientRecord(patientId)
 * Returns the raw KYC row for a patient ID.
 */
function _getPatientRecord(patientId) {
  const all = getSheetData(SHEET_NAMES.KYC);
  return all.find(p => p['Patient_ID'] === patientId) || null;
}

/**
 * _finToday()
 * Returns today as "YYYY-MM-DD" in the clinic timezone.
 */
function _finToday() {
  const tz = getSetting('Timezone') || 'Asia/Kolkata';
  return Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');
}

/**
 * _sumField(rows, field)
 * Sums a numeric field across an array of row objects.
 */
function _sumField(rows, field) {
  return rows.reduce((acc, row) => acc + sanitizeNumber(row[field], 0), 0);
}

/**
 * _getPeriodRange(period, now, tz)
 * Returns { startIso, endIso, label } for a named period.
 */
function _getPeriodRange(period, now, tz) {
  const todayStr = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
  const year     = now.getFullYear();
  const month    = now.getMonth(); // 0-indexed

  let startIso, endIso, label;

  switch (period) {
    case 'today':
      startIso = todayStr;
      endIso   = todayStr;
      label    = 'Today — ' + Utilities.formatDate(now, tz, 'd MMM yyyy');
      break;

    case 'week': {
      const d   = new Date(now);
      const day = d.getDay() || 7;     // Mon=1 … Sun=7
      d.setDate(d.getDate() - day + 1); // Monday
      startIso = Utilities.formatDate(d, tz, 'yyyy-MM-dd');
      endIso   = todayStr;
      label    = 'This Week';
      break;
    }

    case 'year':
      startIso = year + '-01-01';
      endIso   = year + '-12-31';
      label    = 'Year ' + year;
      break;

    case 'month':
    default: {
      const firstDay = new Date(year, month, 1);
      const lastDay  = new Date(year, month + 1, 0);
      startIso = Utilities.formatDate(firstDay, tz, 'yyyy-MM-dd');
      endIso   = Utilities.formatDate(lastDay,  tz, 'yyyy-MM-dd');
      label    = Utilities.formatDate(now, tz, 'MMMM yyyy');
      break;
    }
  }

  return { startIso, endIso, label };
}
