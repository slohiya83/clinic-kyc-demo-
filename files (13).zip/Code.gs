// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Code.gs
//  Version     : 1.4.0
//  Changes     : Phase 5 — Dashboard live
// ============================================================

const SYSTEM_VERSION = '1.4.0';

const SHEET_NAMES = {
  SETTINGS    : 'Settings',
  KYC         : 'KYC_Data',
  APPOINTMENTS: 'Appointments',
  SALES       : 'Sales',
  EXPENSES    : 'Expenses',
  DASHBOARD   : 'Dashboard_Data',
  LOG         : 'System_Log'
};

const SETTINGS_KEYS = {
  CLINIC_NAME     : 'Clinic_Name',
  LOGO_URL        : 'Logo_URL',
  PRIMARY_COLOR   : 'Primary_Color',
  SECONDARY_COLOR : 'Secondary_Color',
  PHONE_NUMBER    : 'Phone_Number',
  ADDRESS         : 'Address',
  CURRENCY        : 'Currency',
  DATE_FORMAT     : 'Date_Format',
  TIMEZONE        : 'Timezone',
  ADMIN_EMAIL     : 'Admin_Email'
};

function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('🏥 Clinic System')
    .addItem('✅ Initialize System', 'initSystem')
    .addSeparator()
    .addSubMenu(
      ui.createMenu('📋 Patient (KYC)')
        .addItem('➕ Register New Patient',  'openNewPatientForm')
        .addItem('🔍 Search / Edit Patient', 'openPatientSearch')
    )
    .addSubMenu(
      ui.createMenu('📅 Appointments')
        .addItem("📆 Today's Schedule",      'openTodaySchedule')
        .addItem('➕ Book Appointment',       'openNewAppointmentForm')
    )
    .addSubMenu(
      ui.createMenu('💰 Finance')
        .addItem('🧾 Record Sale',           'openSaleForm')
        .addItem('💸 Record Expense',        'openExpenseForm')
        .addSeparator()
        .addItem('📈 Finance Summary',       'openFinanceSummary')
    )
    .addSeparator()
    .addItem('📊 Open Dashboard',   'openDashboard')
    .addSeparator()
    .addItem('⚙️  System Settings', 'openSettings')
    .addItem('📜 View System Log',  'viewSystemLog')
    .addToUi();
}

function initSystem() {
  const ui = SpreadsheetApp.getUi();
  try {
    _log('INFO', 'initSystem', 'Initialization started.');
    _createSettingsSheet();
    _createKYCSheet();
    _createAppointmentsSheet();
    _createSalesSheet();
    _createExpensesSheet();
    _createDashboardSheet();
    _createLogSheet();
    const settings   = getSettings();
    const clinicName = settings[SETTINGS_KEYS.CLINIC_NAME] || 'Your Clinic';
    _log('INFO', 'initSystem', 'System initialized — v' + SYSTEM_VERSION + ' — ' + clinicName);
    ui.alert(
      '✅ System Ready — v' + SYSTEM_VERSION,
      'Clinic  : ' + clinicName + '\n' +
      'Version : ' + SYSTEM_VERSION + '\n\n' +
      '✅ Phase 1 — Base System\n' +
      '✅ Phase 2 — Patient (KYC) Module\n' +
      '✅ Phase 3 — Appointments Module\n' +
      '✅ Phase 4 — Finance (Sales & Expenses)\n' +
      '✅ Phase 5 — Dashboard\n\n' +
      'System is complete! 🎉\n\n' +
      'Use 🏥 Clinic System menu to begin.',
      ui.ButtonSet.OK
    );
  } catch (err) {
    _log('ERROR', 'initSystem', err.message);
    ui.alert('❌ Error', err.message, ui.ButtonSet.OK);
  }
}

function openSettings() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAMES.SETTINGS);
  if (!sheet) { SpreadsheetApp.getUi().alert('Run Initialize System first.'); return; }
  ss.setActiveSheet(sheet);
}

function viewSystemLog() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAMES.LOG);
  if (!sheet) { SpreadsheetApp.getUi().alert('Run Initialize System first.'); return; }
  ss.setActiveSheet(sheet);
}
