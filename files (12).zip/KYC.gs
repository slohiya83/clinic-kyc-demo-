// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : KYC.gs
//  Phase       : 2 — Patient / KYC Module
//  Description : Full backend for patient management.
//                Handles registration, search, edit, status.
//                All functions called via google.script.run
//                from KYCForm.html and KYCSearch.html sidebars.
// ============================================================


// ════════════════════════════════════════════════════════════
//  SIDEBAR LAUNCHERS  (called from the menu)
// ════════════════════════════════════════════════════════════

/**
 * openNewPatientForm()
 * Opens the "New Patient Registration" sidebar.
 */
function openNewPatientForm() {
  const html = HtmlService
    .createHtmlOutputFromFile('KYCForm')
    .setTitle('New Patient Registration')
    .setWidth(420);

  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openNewPatientForm', 'KYC registration sidebar opened.');
}

/**
 * openPatientSearch()
 * Opens the "Search Patient" sidebar.
 */
function openPatientSearch() {
  const html = HtmlService
    .createHtmlOutputFromFile('KYCSearch')
    .setTitle('Patient Search')
    .setWidth(440);

  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openPatientSearch', 'Patient search sidebar opened.');
}

/**
 * openEditPatientForm(patientId)
 * Opens the Edit Patient sidebar pre-filled for a given Patient ID.
 * Called from the search sidebar when user clicks "Edit".
 *
 * @param {string} patientId - e.g. "PAT-2025-0001"
 */
function openEditPatientForm(patientId) {
  const html = HtmlService
    .createTemplateFromFile('KYCForm');

  html.editMode   = true;
  html.patientId  = patientId;

  const output = html.evaluate()
    .setTitle('Edit Patient — ' + patientId)
    .setWidth(420);

  SpreadsheetApp.getUi().showSidebar(output);
  _log('INFO', 'openEditPatientForm', `Edit sidebar opened for: ${patientId}`);
}


// ════════════════════════════════════════════════════════════
//  CORE BACKEND — CALLED via google.script.run
// ════════════════════════════════════════════════════════════

/**
 * getClinicSettings()
 * ─────────────────────────────────────────────────────────────
 * Returns branding settings needed by the sidebar UI.
 * Called once on sidebar load to apply clinic colors / name.
 *
 * @returns {{ clinicName, primaryColor, currency }}
 */
function getClinicSettings() {
  const s = getSettings();
  return {
    clinicName   : s['Clinic_Name']    || 'My Clinic',
    primaryColor : s['Primary_Color']  || '#1a73e8',
    currency     : s['Currency']       || '₹'
  };
}


/**
 * submitNewPatient(formData)
 * ─────────────────────────────────────────────────────────────
 * Validates, de-duplicates, and saves a new patient record.
 * Called from KYCForm.html via google.script.run.
 *
 * @param  {Object} formData  - Raw form values from sidebar
 * @returns {{ success, patientId, message }}
 */
function submitNewPatient(formData) {
  try {
    // 1. Validate required fields (pure JS — no sheet reads)
    const validation = validateRequiredFields(formData, [
      'fullName', 'phone', 'gender', 'dateOfBirth'
    ]);
    if (!validation.valid) {
      return {
        success : false,
        message : 'Please fill in: ' + validation.missing.join(', ')
      };
    }

    // 2. Sanitize inputs
    const name  = sanitizeText(formData.fullName);
    const phone = sanitizeText(formData.phone);

    if (!isValidPhone(phone)) {
      return { success: false, message: 'Phone number format is invalid.' };
    }
    if (formData.email && !isValidEmail(formData.email)) {
      return { success: false, message: 'Email address format is invalid.' };
    }

    // ── PERF FIX: read ALL data in two batches up front ──────────────────────
    // Old code triggered 6 separate sheet reads scattered across helpers.
    // Now we do ONE settings read + ONE KYC read, then everything runs in memory.

    // Batch 1: settings (used for ID prefix, sequence counter, timezone)
    const settings = getSettings();                          // READ 1 (Settings)

    // Batch 2: KYC sheet (used for duplicate phone check)
    const ss        = SpreadsheetApp.getActiveSpreadsheet();
    const kycSheet  = ss.getSheetByName(SHEET_NAMES.KYC);
    const kycData   = kycSheet ? kycSheet.getDataRange().getValues() : []; // READ 2 (KYC)
    const kycHeader = kycData[0] || [];

    // 3. Duplicate phone check — runs on already-loaded kycData (no extra read)
    const phoneCol = kycHeader.indexOf('Phone');
    const idCol    = kycHeader.indexOf('Patient_ID');
    const nameCol  = kycHeader.indexOf('Full_Name');

    if (phoneCol !== -1) {
      for (let i = 1; i < kycData.length; i++) {
        if (sanitizeText(String(kycData[i][phoneCol])) === sanitizeText(phone)) {
          return {
            success   : false,
            duplicate : true,
            message   : `Phone already registered to patient ${kycData[i][idCol]} — ${kycData[i][nameCol]}`
          };
        }
      }
    }

    // 4. Calculate age from DOB (pure JS)
    const age = _calcAge(formData.dateOfBirth);

    // 5. Generate unique ID — reads from already-loaded settings, then ONE write
    const prefix  = settings['Patient_ID_Prefix'] || 'PAT';
    const lastSeq = parseInt(settings['Last_Patient_Seq'] || 0, 10);
    const nextSeq = lastSeq + 1;
    const patientId = `${prefix}-${new Date().getFullYear()}-${String(nextSeq).padStart(4, '0')}`;

    // WRITE 1: increment sequence counter
    _updateSettingFast(ss, 'Last_Patient_Seq', nextSeq);

    // 6. Timestamp — derive from settings already in memory (no extra read)
    const tz  = settings['Timezone'] || 'Asia/Kolkata';
    const now = Utilities.formatDate(new Date(), tz, 'dd/MM/yyyy HH:mm:ss');

    // 7. Build row and append — WRITE 2
    const row = [
      patientId,
      name,
      formData.dateOfBirth         || '',
      age,
      formData.gender              || '',
      phone,
      sanitizeText(formData.email            || ''),
      sanitizeText(formData.address          || ''),
      formData.bloodGroup          || '',
      sanitizeText(formData.emergencyContact || ''),
      sanitizeText(formData.medicalHistory   || ''),
      sanitizeText(formData.allergies        || ''),
      sanitizeText(formData.insuranceNo      || ''),
      sanitizeText(formData.referredBy       || ''),
      now,
      now,
      'Active'
    ];

    kycSheet.appendRow(row);  // WRITE 2 — direct, skips appendRowToSheet overhead

    // _highlightNewRow REMOVED — it was causing 800ms forced sleep for a visual
    // effect the user couldn't even see while waiting for the response.

    _log('INFO', 'submitNewPatient', `Registered: ${patientId} — ${name}`);

    return {
      success   : true,
      patientId : patientId,
      message   : `Patient registered!\nID: ${patientId}`
    };

  } catch (err) {
    _log('ERROR', 'submitNewPatient', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


/**
 * _updateSettingFast(ss, key, value)
 * Updates a single Settings row without calling getSettings() again.
 * Accepts the already-open Spreadsheet object to avoid re-fetching it.
 */
function _updateSettingFast(ss, key, value) {
  const sheet = ss.getSheetByName(SHEET_NAMES.SETTINGS);
  if (!sheet) return;
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === key) {
      sheet.getRange(i + 1, 2).setValue(value);
      return;
    }
  }
}


/**
 * searchPatients(query)
 * ─────────────────────────────────────────────────────────────
 * Full-text search across Patient_ID, Full_Name, Phone, Email.
 * Returns up to 20 matches, sorted by most recent first.
 *
 * @param  {string} query
 * @returns {Object[]} Array of matching patient objects
 */
function searchPatients(query) {
  try {
    const term = String(query || '').trim().toLowerCase();
    if (term.length < 2) return [];

    const allPatients = getSheetData(SHEET_NAMES.KYC);

    const results = allPatients.filter(p => {
      return (
        String(p['Patient_ID']  || '').toLowerCase().includes(term) ||
        String(p['Full_Name']   || '').toLowerCase().includes(term) ||
        String(p['Phone']       || '').toLowerCase().includes(term) ||
        String(p['Email']       || '').toLowerCase().includes(term)
      );
    });

    // Most-recently added first; cap at 20
    return results.reverse().slice(0, 20).map(p => ({
      patientId : p['Patient_ID'],
      fullName  : p['Full_Name'],
      phone     : p['Phone'],
      gender    : p['Gender'],
      age       : p['Age'],
      bloodGroup: p['Blood_Group'],
      status    : p['Status'],
      createdAt : p['Created_At']
    }));

  } catch (err) {
    _log('ERROR', 'searchPatients', err.message);
    return [];
  }
}


/**
 * getPatientById(patientId)
 * ─────────────────────────────────────────────────────────────
 * Returns full patient record by ID. Used to pre-fill edit form.
 *
 * @param  {string} patientId
 * @returns {Object|null}
 */
function getPatientById(patientId) {
  try {
    const all = getSheetData(SHEET_NAMES.KYC);
    const patient = all.find(p => p['Patient_ID'] === patientId);

    if (!patient) return null;

    return {
      patientId       : patient['Patient_ID'],
      fullName        : patient['Full_Name'],
      dateOfBirth     : _formatDateForInput(patient['Date_of_Birth']),
      age             : patient['Age'],
      gender          : patient['Gender'],
      phone           : patient['Phone'],
      email           : patient['Email'],
      address         : patient['Address'],
      bloodGroup      : patient['Blood_Group'],
      emergencyContact: patient['Emergency_Contact'],
      medicalHistory  : patient['Medical_History'],
      allergies       : patient['Allergies'],
      insuranceNo     : patient['Insurance_No'],
      referredBy      : patient['Referred_By'],
      createdAt       : patient['Created_At'],
      updatedAt       : patient['Updated_At'],
      status          : patient['Status']
    };

  } catch (err) {
    _log('ERROR', 'getPatientById', err.message);
    return null;
  }
}


/**
 * updatePatient(patientId, formData)
 * ─────────────────────────────────────────────────────────────
 * Updates editable fields for an existing patient.
 * Patient_ID and Created_At are never changed.
 *
 * @param  {string} patientId
 * @param  {Object} formData
 * @returns {{ success, message }}
 */
function updatePatient(patientId, formData) {
  try {
    const validation = validateRequiredFields(formData, [
      'fullName', 'phone', 'gender', 'dateOfBirth'
    ]);
    if (!validation.valid) {
      return {
        success : false,
        message : 'Please fill in: ' + validation.missing.join(', ')
      };
    }

    const phone = sanitizeText(formData.phone);
    if (!isValidPhone(phone)) {
      return { success: false, message: 'Phone number format is invalid.' };
    }
    if (formData.email && !isValidEmail(formData.email)) {
      return { success: false, message: 'Email address format is invalid.' };
    }

    // Duplicate phone check — exclude current patient
    const dup = _findPatientByPhone(phone);
    if (dup && dup['Patient_ID'] !== patientId) {
      return {
        success : false,
        message : `Phone already registered to patient ${dup['Patient_ID']} — ${dup['Full_Name']}`
      };
    }

    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.KYC);
    const data  = sheet.getDataRange().getValues();

    // Find the row (index 0 = header, so sheet row = i+1)
    let targetRow = -1;
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === patientId) { targetRow = i + 1; break; }
    }

    if (targetRow === -1) {
      return { success: false, message: `Patient ID ${patientId} not found.` };
    }

    const age = _calcAge(formData.dateOfBirth);
    const now = getTimestamp();

    // Write only the editable columns (keep A=Patient_ID and O=Created_At intact)
    const updates = [
      [sanitizeText(formData.fullName)],                  // B
      [formData.dateOfBirth || ''],                        // C
      [age],                                               // D
      [formData.gender || ''],                             // E
      [phone],                                             // F
      [sanitizeText(formData.email || '')],                // G
      [sanitizeText(formData.address || '')],              // H
      [formData.bloodGroup || ''],                         // I
      [sanitizeText(formData.emergencyContact || '')],     // J
      [sanitizeText(formData.medicalHistory || '')],       // K
      [sanitizeText(formData.allergies || '')],            // L
      [sanitizeText(formData.insuranceNo || '')],          // M
      [sanitizeText(formData.referredBy || '')],           // N
    ];

    // Write cols B–N (columns 2–14)
    updates.forEach((val, idx) => {
      sheet.getRange(targetRow, idx + 2).setValue(val[0]);
    });
    // Col P = Updated_At
    sheet.getRange(targetRow, 16).setValue(now);
    // Col Q = Status
    sheet.getRange(targetRow, 17).setValue(formData.status || 'Active');

    _log('INFO', 'updatePatient', `Patient updated: ${patientId}`);
    return { success: true, message: `Patient ${patientId} updated successfully.` };

  } catch (err) {
    _log('ERROR', 'updatePatient', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


/**
 * togglePatientStatus(patientId)
 * ─────────────────────────────────────────────────────────────
 * Toggles a patient's status between Active and Inactive.
 * Soft-delete pattern — record is never physically removed.
 *
 * @param  {string} patientId
 * @returns {{ success, newStatus, message }}
 */
function togglePatientStatus(patientId) {
  try {
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.KYC);
    const data  = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === patientId) {
        const currentStatus = data[i][16]; // Column Q
        const newStatus     = (currentStatus === 'Active') ? 'Inactive' : 'Active';

        sheet.getRange(i + 1, 17).setValue(newStatus);   // Q
        sheet.getRange(i + 1, 16).setValue(getTimestamp()); // P Updated_At

        _log('INFO', 'togglePatientStatus',
          `${patientId} status changed: ${currentStatus} → ${newStatus}`);

        return { success: true, newStatus, message: `Status set to ${newStatus}.` };
      }
    }

    return { success: false, message: 'Patient not found.' };

  } catch (err) {
    _log('ERROR', 'togglePatientStatus', err.message);
    return { success: false, message: 'Error: ' + err.message };
  }
}


/**
 * getPatientStats()
 * ─────────────────────────────────────────────────────────────
 * Returns headline stats shown at the top of the search sidebar.
 *
 * @returns {{ total, active, today, thisMonth }}
 */
function getPatientStats() {
  try {
    const all      = getSheetData(SHEET_NAMES.KYC);
    const tz       = getSetting('Timezone') || 'Asia/Kolkata';
    const todayStr = Utilities.formatDate(new Date(), tz, 'dd/MM/yyyy');
    const monthStr = Utilities.formatDate(new Date(), tz, 'MM/yyyy');

    const total     = all.length;
    const active    = all.filter(p => p['Status'] === 'Active').length;
    const today     = all.filter(p =>
      String(p['Created_At'] || '').startsWith(todayStr)).length;
    const thisMonth = all.filter(p =>
      String(p['Created_At'] || '').includes(monthStr)).length;

    return { total, active, today, thisMonth };

  } catch (err) {
    _log('ERROR', 'getPatientStats', err.message);
    return { total: 0, active: 0, today: 0, thisMonth: 0 };
  }
}


/**
 * navigateToPatientRow(patientId)
 * ─────────────────────────────────────────────────────────────
 * Scrolls the spreadsheet to the patient's row in KYC_Data.
 * Called from search sidebar "Go to row" action.
 */
function navigateToPatientRow(patientId) {
  try {
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.KYC);
    const data  = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === patientId) {
        ss.setActiveSheet(sheet);
        sheet.setActiveRange(sheet.getRange(i + 1, 1));
        SpreadsheetApp.flush();
        _log('INFO', 'navigateToPatientRow', `Navigated to row ${i + 1} for ${patientId}`);
        return;
      }
    }
  } catch (err) {
    _log('ERROR', 'navigateToPatientRow', err.message);
  }
}


// ════════════════════════════════════════════════════════════
//  PRIVATE HELPERS
// ════════════════════════════════════════════════════════════

/**
 * _calcAge(dobString)
 * Computes current age in years from a DOB string.
 * Accepts "YYYY-MM-DD" (HTML date input) or "DD/MM/YYYY".
 */
function _calcAge(dobString) {
  if (!dobString) return '';

  let dob;
  if (/^\d{4}-\d{2}-\d{2}$/.test(dobString)) {
    // ISO format from HTML date input
    dob = new Date(dobString);
  } else if (/^\d{2}\/\d{2}\/\d{4}$/.test(dobString)) {
    // DD/MM/YYYY
    const parts = dobString.split('/');
    dob = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
  } else {
    return '';
  }

  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;

  return age >= 0 && age < 150 ? age : '';
}

/**
 * _findPatientByPhone(phone)
 * Returns the first patient with matching phone, or null.
 */
function _findPatientByPhone(phone) {
  const all = getSheetData(SHEET_NAMES.KYC);
  return all.find(p => sanitizeText(String(p['Phone'])) === sanitizeText(phone)) || null;
}

/**
 * _formatDateForInput(dateValue)
 * Converts a sheet date value to "YYYY-MM-DD" for HTML date inputs.
 */
function _formatDateForInput(dateValue) {
  if (!dateValue) return '';

  try {
    if (dateValue instanceof Date) {
      return Utilities.formatDate(dateValue, 'UTC', 'yyyy-MM-dd');
    }
    const str = String(dateValue);
    // Already ISO
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
    // DD/MM/YYYY
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(str)) {
      const [d, m, y] = str.split('/');
      return `${y}-${m}-${d}`;
    }
    return '';
  } catch (e) {
    return '';
  }
}

/**
 * _highlightNewRow(sheetName)
 * Briefly highlights the last row in a light green flash.
 * Gives visual feedback when a new record is saved.
 */
function _highlightNewRow(sheetName) {
  // Kept for any callers outside KYC, but sleep removed.
  // submitNewPatient no longer calls this at all — the 800ms
  // Utilities.sleep() was the single biggest performance killer.
  try {
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return;
    sheet.getRange(lastRow, 1, 1, sheet.getLastColumn()).setBackground('#c8e6c9');
    // No sleep. No reset. Green row stays until next edit — user can see it.
  } catch (e) { /* non-critical */ }
}
