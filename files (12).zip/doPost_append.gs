// ============================================================
//  KYC.gs  — APPEND THIS TO THE BOTTOM OF YOUR EXISTING FILE
//  Phase   : 2.1 — External API Endpoint  (v2 — CORS fix)
// ============================================================


/**
 * doGet(e)
 * ─────────────────────────────────────────────────────────────
 * Deployment health-check. Open the Web App URL in a browser —
 * if you see {"status":"ok"} the deployment is working.
 * If you see a Google login page, set access to "Anyone".
 */
function doGet(e) {
  return _jsonResponse({ status: 'ok', version: '2.1', message: 'KYC Web App is live.' });
}


/**
 * doPost(e)
 * ─────────────────────────────────────────────────────────────
 * Accepts JSON POST from Vercel / any external form.
 *
 * WHY this works without CORS preflight:
 *   The fetch on Vercel sends Content-Type: text/plain — this
 *   is a "simple" request so the browser skips the OPTIONS
 *   preflight that Apps Script can't respond to.
 *
 * Incoming JSON:
 *   { name, phone, dob, gender, problem }
 *
 * Response JSON:
 *   { success: true,  patientId: "PAT-2025-0001" }
 *   { success: false, error: "reason" }
 */
function doPost(e) {
  try {

    // 1. Parse body
    if (!e || !e.postData || !e.postData.contents) {
      return _jsonResponse({ success: false, error: 'Empty request body.' });
    }

    let incoming;
    try {
      incoming = JSON.parse(e.postData.contents);
    } catch (_) {
      return _jsonResponse({
        success: false,
        error  : 'Invalid JSON. Received: ' + String(e.postData.contents).slice(0, 120)
      });
    }

    // 2. Map external field names → internal formData shape
    const formData = {
      fullName         : incoming.name            || '',
      phone            : incoming.phone           || '',
      dateOfBirth      : incoming.dob             || '',
      gender           : incoming.gender          || '',
      medicalHistory   : incoming.problem         || '',
      email            : incoming.email           || '',
      address          : incoming.address         || '',
      bloodGroup       : incoming.bloodGroup      || '',
      emergencyContact : incoming.emergencyContact|| '',
      allergies        : incoming.allergies       || '',
      insuranceNo      : incoming.insuranceNo     || '',
      referredBy       : incoming.referredBy      || 'External Form'
    };

    // 3. Delegate to existing pipeline — all validation + ID gen is there
    const result = submitNewPatient(formData);

    // 4. Return result
    if (result.success) {
      return _jsonResponse({ success: true, patientId: result.patientId });
    } else {
      return _jsonResponse({
        success  : false,
        error    : result.message,
        duplicate: result.duplicate || false
      });
    }

  } catch (err) {
    _log('ERROR', 'doPost', err.message);
    return _jsonResponse({ success: false, error: 'Server error: ' + err.message });
  }
}


/**
 * _jsonResponse(obj)
 * ContentService JSON wrapper — MIME type tells the browser
 * to parse the body as JSON even across the redirect.
 */
function _jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
