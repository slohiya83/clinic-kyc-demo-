// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Dashboard.gs
//  Phase       : 5 — Dashboard Module
//  Version     : 1.4.0
//  Description : Dashboard backend. Aggregates ALL data from
//                KYC, Appointments, Sales, Expenses in a
//                SINGLE function call — no multiple round-trips
//                from the sidebar. Zero duplicate logic —
//                reuses existing module helpers throughout.
// ============================================================


// ════════════════════════════════════════════════════════════
//  SIDEBAR LAUNCHER
// ════════════════════════════════════════════════════════════

function openDashboard() {
  const html = HtmlService
    .createHtmlOutputFromFile('Dashboard')
    .setTitle('📊 Clinic Dashboard')
    .setWidth(480);
  SpreadsheetApp.getUi().showSidebar(html);
  _log('INFO', 'openDashboard', 'Dashboard sidebar opened.');
}


// ════════════════════════════════════════════════════════════
//  MAIN DATA AGGREGATOR — single round-trip
// ════════════════════════════════════════════════════════════

/**
 * getDashboardData()
 * ─────────────────────────────────────────────────────────────
 * Called ONCE on dashboard load. Returns everything the UI
 * needs — settings, KPIs, trends, today's schedule, recent
 * patients, top expense categories — in one object.
 *
 * Design rule: each sheet is read ONCE and reused for all
 * calculations. No sheet is opened twice.
 *
 * @returns {Object} Full dashboard payload
 */
function getDashboardData() {
  try {
    const ss  = SpreadsheetApp.getActiveSpreadsheet();
    const tz  = getSetting('Timezone') || 'Asia/Kolkata';
    const now = new Date();

    // ── Branding ─────────────────────────────────────────────
    const settings   = getSettings();
    const clinicName = settings['Clinic_Name']   || 'My Clinic';
    const currency   = settings['Currency']      || '₹';
    const color      = settings['Primary_Color'] || '#1a73e8';

    // ── Date helpers ─────────────────────────────────────────
    const todayIso  = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
    const monthStr  = Utilities.formatDate(now, tz, 'yyyy-MM');
    const todayDisp = Utilities.formatDate(now, tz, 'EEEE, d MMM yyyy');
    const year      = now.getFullYear();

    // ── Read all sheets ONCE ──────────────────────────────────
    const allPatients    = getSheetData(SHEET_NAMES.KYC);
    const allAppts       = getSheetData(SHEET_NAMES.APPOINTMENTS);
    const allSales       = getSheetData(SHEET_NAMES.SALES);
    const allExpenses    = getSheetData(SHEET_NAMES.EXPENSES);

    // ════════════════════════════════════════════════════════
    //  KPI — PATIENTS
    // ════════════════════════════════════════════════════════
    const totalPatients  = allPatients.length;
    const activePatients = allPatients.filter(p => p['Status'] === 'Active').length;
    const newThisMonth   = allPatients.filter(p => {
      const d = String(p['Created_At'] || '');
      // Created_At format: "DD/MM/YYYY HH:mm:ss" — monthStr is "YYYY-MM"
      const parts = d.split('/');
      if (parts.length < 3) return false;
      const iso = `${parts[2].slice(0,4)}-${parts[1]}-${parts[0]}`;
      return iso.startsWith(monthStr);
    }).length;
    const newToday = allPatients.filter(p =>
      String(p['Created_At'] || '').startsWith(
        Utilities.formatDate(now, tz, 'dd/MM/yyyy')
      )
    ).length;

    // ════════════════════════════════════════════════════════
    //  KPI — APPOINTMENTS
    // ════════════════════════════════════════════════════════
    const todayAppts     = allAppts.filter(a => _normalizeDate(a['Appt_Date']) === todayIso);
    const monthAppts     = allAppts.filter(a => (_normalizeDate(a['Appt_Date']) || '').startsWith(monthStr));
    const completedToday = todayAppts.filter(a => a['Status'] === 'Completed').length;
    const pendingToday   = todayAppts.filter(a => ['Scheduled','Rescheduled'].includes(a['Status'])).length;
    const cancelledToday = todayAppts.filter(a => a['Status'] === 'Cancelled').length;
    const completionRate = monthAppts.length > 0
      ? Math.round(monthAppts.filter(a => a['Status'] === 'Completed').length / monthAppts.length * 100)
      : 0;

    // ════════════════════════════════════════════════════════
    //  KPI — REVENUE
    // ════════════════════════════════════════════════════════
    const todaySales     = allSales.filter(s => String(s['Sale_Date'] || '').slice(0,10) === todayIso);
    const monthSales     = allSales.filter(s => String(s['Sale_Date'] || '').startsWith(monthStr));
    const yearSales      = allSales.filter(s => String(s['Sale_Date'] || '').startsWith(String(year)));

    const todayRevenue   = _dash_sum(todaySales,  'Total_Amount');
    const monthRevenue   = _dash_sum(monthSales,  'Total_Amount');
    const yearRevenue    = _dash_sum(yearSales,   'Total_Amount');

    const pendingPay     = allSales
      .filter(s => s['Payment_Status'] === 'Pending' || s['Payment_Status'] === 'Partial')
      .reduce((a, s) => a + sanitizeNumber(s['Total_Amount'], 0), 0);

    // ════════════════════════════════════════════════════════
    //  KPI — EXPENSES & PROFIT
    // ════════════════════════════════════════════════════════
    const monthExpenses  = allExpenses.filter(e => String(e['Expense_Date'] || '').startsWith(monthStr));
    const todayExpenses  = allExpenses.filter(e => String(e['Expense_Date'] || '').slice(0,10) === todayIso);

    const monthExpAmt    = _dash_sum(monthExpenses, 'Amount');
    const todayExpAmt    = _dash_sum(todayExpenses, 'Amount');
    const monthProfit    = parseFloat((monthRevenue - monthExpAmt).toFixed(2));
    const profitMargin   = monthRevenue > 0
      ? Math.round(monthProfit / monthRevenue * 100)
      : 0;

    // ════════════════════════════════════════════════════════
    //  REVENUE TREND — last 7 days
    // ════════════════════════════════════════════════════════
    const trend7 = [];
    for (let i = 6; i >= 0; i--) {
      const d    = new Date(now);
      d.setDate(d.getDate() - i);
      const iso  = Utilities.formatDate(d, tz, 'yyyy-MM-dd');
      const lbl  = Utilities.formatDate(d, tz, 'EEE'); // Mon, Tue…
      const rev  = allSales
        .filter(s => String(s['Sale_Date'] || '').slice(0,10) === iso)
        .reduce((a, s) => a + sanitizeNumber(s['Total_Amount'], 0), 0);
      const exp  = allExpenses
        .filter(e => String(e['Expense_Date'] || '').slice(0,10) === iso)
        .reduce((a, e) => a + sanitizeNumber(e['Amount'], 0), 0);
      trend7.push({ date: iso, label: lbl, revenue: rev, expense: exp });
    }

    // ════════════════════════════════════════════════════════
    //  TODAY'S APPOINTMENTS — for the schedule strip
    // ════════════════════════════════════════════════════════
    const scheduleToday = todayAppts
      .sort((a, b) => _timeSlotToMinutes(a['Time_Slot']) - _timeSlotToMinutes(b['Time_Slot']))
      .slice(0, 8)
      .map(a => ({
        apptId     : a['Appt_ID'],
        timeSlot   : a['Time_Slot'],
        patientName: a['Patient_Name'],
        doctor     : a['Doctor'],
        apptType   : a['Appt_Type'],
        status     : a['Status'],
        fee        : a['Consultation_Fee']
      }));

    // ════════════════════════════════════════════════════════
    //  RECENT PATIENTS — last 5 registered
    // ════════════════════════════════════════════════════════
    const recentPatients = allPatients
      .slice(-5)
      .reverse()
      .map(p => ({
        patientId: p['Patient_ID'],
        fullName : p['Full_Name'],
        phone    : p['Phone'],
        gender   : p['Gender'],
        status   : p['Status']
      }));

    // ════════════════════════════════════════════════════════
    //  TOP EXPENSE CATEGORIES — this month
    // ════════════════════════════════════════════════════════
    const expByCat = {};
    monthExpenses.forEach(e => {
      const c = e['Category'] || 'Other';
      expByCat[c] = (expByCat[c] || 0) + sanitizeNumber(e['Amount'], 0);
    });
    const topExpCats = Object.entries(expByCat)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([cat, amt]) => ({ cat, amt: parseFloat(amt.toFixed(2)) }));

    // ════════════════════════════════════════════════════════
    //  PAYMENT MODE BREAKDOWN — this month
    // ════════════════════════════════════════════════════════
    const payModes = {};
    monthSales.forEach(s => {
      const m = s['Payment_Mode'] || 'Other';
      payModes[m] = (payModes[m] || 0) + sanitizeNumber(s['Total_Amount'], 0);
    });

    // ════════════════════════════════════════════════════════
    //  ALSO WRITE TO Dashboard_Data SHEET
    // ════════════════════════════════════════════════════════
    _writeDashboardSheet(ss, tz, {
      clinicName, todayDisp,
      totalPatients, activePatients, newThisMonth,
      todayRevenue, monthRevenue, yearRevenue, pendingPay,
      monthExpAmt, monthProfit, profitMargin,
      todayAppts: todayAppts.length, completedToday, pendingToday
    });

    _log('INFO', 'getDashboardData',
      `Dashboard loaded — Revenue: ${currency}${monthRevenue} | Patients: ${totalPatients}`);

    // ── Return full payload ───────────────────────────────────
    return {
      // Meta
      clinicName, currency, color, todayDisp,

      // Patient KPIs
      totalPatients, activePatients, newThisMonth, newToday,

      // Appointment KPIs
      apptToday       : todayAppts.length,
      completedToday, pendingToday, cancelledToday, completionRate,
      apptThisMonth   : monthAppts.length,

      // Revenue KPIs
      todayRevenue, monthRevenue, yearRevenue, pendingPay,

      // Expense & Profit KPIs
      todayExpAmt, monthExpAmt, monthProfit, profitMargin,

      // Charts & lists
      trend7, scheduleToday, recentPatients, topExpCats, payModes
    };

  } catch (err) {
    _log('ERROR', 'getDashboardData', err.message);
    return { error: err.message };
  }
}


// ════════════════════════════════════════════════════════════
//  WRITE KPIs TO Dashboard_Data SHEET
// ════════════════════════════════════════════════════════════

/**
 * _writeDashboardSheet(ss, tz, kpis)
 * Updates the Dashboard_Data sheet so admins can build
 * their own Google Sheets charts from live KPI data.
 */
function _writeDashboardSheet(ss, tz, kpis) {
  try {
    const sheet = ss.getSheetByName(SHEET_NAMES.DASHBOARD);
    if (!sheet) return;

    const now  = Utilities.formatDate(new Date(), tz, 'dd/MM/yyyy HH:mm:ss');
    const mon  = Utilities.formatDate(new Date(), tz, 'MMMM yyyy');

    // Map metric name → value (col B), previous (col C blank for now),
    // change% (col D blank), period label (col E), last updated (col F)
    const rows = [
      ['Total Revenue',         kpis.monthRevenue,    '', '', mon, now],
      ['Total Expenses',        kpis.monthExpAmt,     '', '', mon, now],
      ['Net Profit',            kpis.monthProfit,     '', '', mon, now],
      ['Profit Margin %',       kpis.profitMargin,    '', '', mon, now],
      ['Total Patients',        kpis.totalPatients,   '', '', mon, now],
      ['New Patients',          kpis.newThisMonth,    '', '', mon, now],
      ['Total Appointments',    kpis.apptToday,       '', '', 'Today', now],
      ['Completed Appointments',kpis.completedToday,  '', '', 'Today', now],
      ['Completion Rate %',     kpis.completionRate || 0, '', '', mon, now],
      ['Today Revenue',         kpis.todayRevenue,    '', '', 'Today', now],
      ['Outstanding Payments',  kpis.pendingPay,      '', '', 'All Time', now],
      ['Active Patients',       kpis.activePatients,  '', '', 'Current', now]
    ];

    // Write starting from row 2 (row 1 is headers)
    if (sheet.getLastRow() < 2) {
      sheet.getRange(2, 1, rows.length, 6).setValues(rows);
    } else {
      sheet.getRange(2, 1, rows.length, 6).setValues(rows);
    }
  } catch (e) {
    // Non-critical — don't block dashboard load
    Logger.log('[_writeDashboardSheet] Error: ' + e.message);
  }
}


// ════════════════════════════════════════════════════════════
//  PRIVATE HELPERS
// ════════════════════════════════════════════════════════════

function _dash_sum(rows, field) {
  return parseFloat(
    rows.reduce((a, r) => a + sanitizeNumber(r[field], 0), 0).toFixed(2)
  );
}

// Reuses _normalizeDate from Appointments.gs (global scope)
// Reuses _timeSlotToMinutes from Appointments.gs (global scope)
