// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : SheetBuilders.gs
//  Description : Creates all data sheets with proper column
//                structures, formatting, and data validations.
//                Called once during initSystem().
// ============================================================


// ════════════════════════════════════════════════════════════
//  KYC / PATIENT DATA SHEET
// ════════════════════════════════════════════════════════════

/**
 * _createKYCSheet()
 * Columns: Patient_ID | Full_Name | DOB | Age | Gender |
 *          Phone | Email | Address | Blood_Group |
 *          Emergency_Contact | Medical_History | Allergies |
 *          Created_At | Updated_At | Status
 */
function _createKYCSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (ss.getSheetByName(SHEET_NAMES.KYC)) {
    _log('INFO', '_createKYCSheet', 'KYC_Data sheet already exists. Skipped.');
    return;
  }

  const sheet = ss.insertSheet(SHEET_NAMES.KYC);

  const headers = [
    'Patient_ID',        // A  — Auto-generated (PAT-2025-0001)
    'Full_Name',         // B
    'Date_of_Birth',     // C
    'Age',               // D  — Auto-calculated
    'Gender',            // E  — Dropdown: Male/Female/Other
    'Phone',             // F
    'Email',             // G
    'Address',           // H
    'Blood_Group',       // I  — Dropdown: A+/A-/B+/B-/AB+/AB-/O+/O-
    'Emergency_Contact', // J
    'Medical_History',   // K
    'Allergies',         // L
    'Insurance_No',      // M
    'Referred_By',       // N
    'Created_At',        // O  — Auto-timestamp
    'Updated_At',        // P  — Auto-timestamp on edit
    'Status'             // Q  — Active/Inactive
  ];

  setSheetHeaders(sheet, headers);

  // ── Data Validations ───────────────────────────────────────
  // Gender dropdown
  const genderRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Male', 'Female', 'Other', 'Prefer Not to Say'], true)
    .build();
  sheet.getRange('E2:E10000').setDataValidation(genderRule);

  // Blood Group dropdown
  const bloodRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'], true)
    .build();
  sheet.getRange('I2:I10000').setDataValidation(bloodRule);

  // Status dropdown
  const statusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Active', 'Inactive', 'Deceased'], true)
    .build();
  sheet.getRange('Q2:Q10000').setDataValidation(statusRule);

  // ── Column Widths ──────────────────────────────────────────
  const widths = [120, 180, 110, 50, 80, 130, 180, 200, 90, 160, 200, 150, 120, 150, 160, 160, 80];
  widths.forEach((w, i) => sheet.setColumnWidth(i + 1, w));

  _log('INFO', '_createKYCSheet', 'KYC_Data sheet created.');
}


// ════════════════════════════════════════════════════════════
//  APPOINTMENTS SHEET
// ════════════════════════════════════════════════════════════

/**
 * _createAppointmentsSheet()
 * Columns: Appt_ID | Patient_ID | Patient_Name | Doctor |
 *          Date | Time_Slot | Type | Status |
 *          Notes | Fees | Created_At | Updated_At
 */
function _createAppointmentsSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (ss.getSheetByName(SHEET_NAMES.APPOINTMENTS)) {
    _log('INFO', '_createAppointmentsSheet', 'Appointments sheet already exists. Skipped.');
    return;
  }

  const sheet = ss.insertSheet(SHEET_NAMES.APPOINTMENTS);

  const headers = [
    'Appt_ID',        // A  — Auto-generated
    'Patient_ID',     // B  — Links to KYC_Data
    'Patient_Name',   // C  — Auto-filled from KYC lookup
    'Doctor',         // D
    'Appt_Date',      // E
    'Time_Slot',      // F  — e.g. "10:00 AM"
    'Appt_Type',      // G  — Consultation/Follow-up/Emergency
    'Status',         // H  — Scheduled/Completed/Cancelled/No-Show
    'Diagnosis',      // I
    'Prescription',   // J
    'Consultation_Fee', // K
    'Notes',          // L
    'Follow_Up_Date', // M
    'Created_At',     // N
    'Updated_At'      // O
  ];

  setSheetHeaders(sheet, headers);

  // ── Data Validations ───────────────────────────────────────
  const apptTypeRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Consultation', 'Follow-Up', 'Emergency', 'Procedure', 'Check-Up'], true)
    .build();
  sheet.getRange('G2:G10000').setDataValidation(apptTypeRule);

  const apptStatusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Scheduled', 'Completed', 'Cancelled', 'No-Show', 'Rescheduled'], true)
    .build();
  sheet.getRange('H2:H10000').setDataValidation(apptStatusRule);

  // ── Column Widths ──────────────────────────────────────────
  const widths = [120, 120, 160, 150, 110, 90, 120, 110, 180, 200, 130, 200, 120, 160, 160];
  widths.forEach((w, i) => sheet.setColumnWidth(i + 1, w));

  _log('INFO', '_createAppointmentsSheet', 'Appointments sheet created.');
}


// ════════════════════════════════════════════════════════════
//  SALES SHEET
// ════════════════════════════════════════════════════════════

/**
 * _createSalesSheet()
 * Columns: Sale_ID | Date | Patient_ID | Patient_Name |
 *          Item_Type | Item_Name | Quantity | Unit_Price |
 *          Discount | Total_Amount | Payment_Mode |
 *          Payment_Status | Invoice_No | Created_At
 */
function _createSalesSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (ss.getSheetByName(SHEET_NAMES.SALES)) {
    _log('INFO', '_createSalesSheet', 'Sales sheet already exists. Skipped.');
    return;
  }

  const sheet = ss.insertSheet(SHEET_NAMES.SALES);

  const headers = [
    'Sale_ID',         // A
    'Sale_Date',       // B
    'Patient_ID',      // C
    'Patient_Name',    // D
    'Item_Type',       // E  — Medicine/Service/Product/Other
    'Item_Name',       // F
    'Quantity',        // G
    'Unit_Price',      // H
    'Discount_Pct',    // I  — Discount %
    'Discount_Amt',    // J  — Auto-calculated
    'Total_Amount',    // K  — Auto-calculated
    'Payment_Mode',    // L  — Cash/Card/UPI/Insurance/Credit
    'Payment_Status',  // M  — Paid/Pending/Partial/Refunded
    'Invoice_No',      // N
    'Notes',           // O
    'Created_At'       // P
  ];

  setSheetHeaders(sheet, headers, '#2e7d32'); // Green header for Sales

  // ── Data Validations ───────────────────────────────────────
  const itemTypeRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Medicine', 'Service', 'Product', 'Lab Test', 'Other'], true)
    .build();
  sheet.getRange('E2:E10000').setDataValidation(itemTypeRule);

  const payModeRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Cash', 'Card', 'UPI', 'Insurance', 'Bank Transfer', 'Credit'], true)
    .build();
  sheet.getRange('L2:L10000').setDataValidation(payModeRule);

  const payStatusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Paid', 'Pending', 'Partial', 'Refunded'], true)
    .build();
  sheet.getRange('M2:M10000').setDataValidation(payStatusRule);

  // ── Auto-calculate formulas (Discount & Total) ─────────────
  // Set formula templates for row 2 onwards
  // Discount_Amt = Quantity * Unit_Price * Discount_Pct / 100
  sheet.getRange('J2').setFormula('=IF(H2="","",G2*H2*I2/100)');
  // Total_Amount = Quantity * Unit_Price - Discount_Amt
  sheet.getRange('K2').setFormula('=IF(H2="","",G2*H2-J2)');

  // ── Column Widths ──────────────────────────────────────────
  const widths = [110, 100, 110, 150, 100, 160, 70, 100, 90, 100, 110, 110, 110, 110, 180, 160];
  widths.forEach((w, i) => sheet.setColumnWidth(i + 1, w));

  _log('INFO', '_createSalesSheet', 'Sales sheet created.');
}


// ════════════════════════════════════════════════════════════
//  EXPENSES SHEET
// ════════════════════════════════════════════════════════════

/**
 * _createExpensesSheet()
 * Columns: Expense_ID | Date | Category | Sub_Category |
 *          Description | Amount | Paid_To | Payment_Mode |
 *          Receipt_No | Approved_By | Notes | Created_At
 */
function _createExpensesSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (ss.getSheetByName(SHEET_NAMES.EXPENSES)) {
    _log('INFO', '_createExpensesSheet', 'Expenses sheet already exists. Skipped.');
    return;
  }

  const sheet = ss.insertSheet(SHEET_NAMES.EXPENSES);

  const headers = [
    'Expense_ID',   // A
    'Expense_Date', // B
    'Category',     // C  — Salary/Supplies/Utilities/Rent/Equipment/Other
    'Sub_Category', // D
    'Description',  // E
    'Amount',       // F
    'Paid_To',      // G
    'Payment_Mode', // H
    'Receipt_No',   // I
    'Approved_By',  // J
    'Is_Recurring', // K  — Yes/No
    'Recur_Period', // L  — Monthly/Weekly/Annually (if recurring)
    'Notes',        // M
    'Created_At'    // N
  ];

  setSheetHeaders(sheet, headers, '#b71c1c'); // Red header for Expenses

  // ── Data Validations ───────────────────────────────────────
  const categoryRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(
      ['Salary', 'Supplies', 'Utilities', 'Rent', 'Equipment',
       'Marketing', 'Maintenance', 'Insurance', 'Miscellaneous'], true)
    .build();
  sheet.getRange('C2:C10000').setDataValidation(categoryRule);

  const payModeRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Cash', 'Card', 'UPI', 'Bank Transfer', 'Cheque'], true)
    .build();
  sheet.getRange('H2:H10000').setDataValidation(payModeRule);

  const recurringRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Yes', 'No'], true)
    .build();
  sheet.getRange('K2:K10000').setDataValidation(recurringRule);

  // ── Column Widths ──────────────────────────────────────────
  const widths = [110, 110, 120, 120, 200, 100, 150, 120, 110, 130, 100, 100, 200, 160];
  widths.forEach((w, i) => sheet.setColumnWidth(i + 1, w));

  _log('INFO', '_createExpensesSheet', 'Expenses sheet created.');
}


// ════════════════════════════════════════════════════════════
//  DASHBOARD DATA SHEET
// ════════════════════════════════════════════════════════════

/**
 * _createDashboardSheet()
 * Acts as a summary/pivot data store.
 * The generateDashboard() function writes computed KPIs here.
 */
function _createDashboardSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (ss.getSheetByName(SHEET_NAMES.DASHBOARD)) {
    _log('INFO', '_createDashboardSheet', 'Dashboard_Data sheet already exists. Skipped.');
    return;
  }

  const sheet = ss.insertSheet(SHEET_NAMES.DASHBOARD);

  const headers = [
    'Metric',            // A  — KPI name
    'Current_Period',    // B  — Value for current period
    'Previous_Period',   // C  — Value for previous period
    'Change_Pct',        // D  — % change
    'Period_Label',      // E  — e.g. "January 2025"
    'Last_Updated'       // F  — Timestamp
  ];

  setSheetHeaders(sheet, headers, '#4a148c'); // Purple for Dashboard

  // ── Placeholder KPI rows ───────────────────────────────────
  const kpis = [
    ['Total Revenue',         '', '', '', '', ''],
    ['Total Expenses',        '', '', '', '', ''],
    ['Net Profit',            '', '', '', '', ''],
    ['Profit Margin %',       '', '', '', '', ''],
    ['Total Patients',        '', '', '', '', ''],
    ['New Patients',          '', '', '', '', ''],
    ['Total Appointments',    '', '', '', '', ''],
    ['Completed Appointments','', '', '', '', ''],
    ['Cancellation Rate %',   '', '', '', '', ''],
    ['Avg Revenue per Patient','','', '', '', ''],
    ['Top Expense Category',  '', '', '', '', ''],
    ['Outstanding Payments',  '', '', '', '', '']
  ];

  sheet.getRange(2, 1, kpis.length, 6).setValues(kpis);

  // Make Metric column bold
  sheet.getRange('A:A').setFontWeight('bold');
  sheet.setColumnWidth(1, 200);
  sheet.setColumnWidth(2, 140);
  sheet.setColumnWidth(3, 140);
  sheet.setColumnWidth(4, 110);
  sheet.setColumnWidth(5, 130);
  sheet.setColumnWidth(6, 160);

  _log('INFO', '_createDashboardSheet', 'Dashboard_Data sheet created.');
}
