// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Utilities.gs
//  Description : Core utility functions shared across ALL modules.
//                These are pure, side-effect-free helpers that
//                any module can call without dependencies.
// ============================================================


// ════════════════════════════════════════════════════════════
//  1. UNIQUE ID GENERATOR
// ════════════════════════════════════════════════════════════

/**
 * generateUniqueId(prefixKey, sequenceKey)
 * ─────────────────────────────────────────────────────────────
 * Generates a sequential, human-readable unique ID.
 * Format: {PREFIX}-{YYYY}-{0001}
 * Example: PAT-2025-0001, APT-2025-0042, SAL-2025-0118
 *
 * The sequence counter is stored in the Settings sheet so it
 * persists across sessions and is visible to admins.
 *
 * @param {string} prefixKey   - Settings key for the prefix   (e.g. 'Patient_ID_Prefix')
 * @param {string} sequenceKey - Settings key for last seq num  (e.g. 'Last_Patient_Seq')
 * @returns {string} Unique ID string
 */
function generateUniqueId(prefixKey, sequenceKey) {
  const settings = getSettings();

  const prefix  = settings[prefixKey]   || 'ID';
  const lastSeq = parseInt(settings[sequenceKey] || 0, 10);
  const nextSeq = lastSeq + 1;

  // Pad sequence to 4 digits
  const paddedSeq = String(nextSeq).padStart(4, '0');

  // Include current year for natural grouping
  const year = new Date().getFullYear();

  const newId = `${prefix}-${year}-${paddedSeq}`;

  // Persist the incremented counter back to Settings
  updateSetting(sequenceKey, nextSeq);

  _log('INFO', 'generateUniqueId', `Generated ID: ${newId}`);
  return newId;
}


/**
 * generatePatientId()
 * Convenience wrapper — generates a Patient ID.
 */
function generatePatientId() {
  return generateUniqueId(
    SETTINGS_KEYS.PATIENT_ID_PREFIX || 'Patient_ID_Prefix',
    'Last_Patient_Seq'
  );
}

/**
 * generateAppointmentId()
 * Convenience wrapper — generates an Appointment ID.
 */
function generateAppointmentId() {
  return generateUniqueId('Appt_ID_Prefix', 'Last_Appt_Seq');
}

/**
 * generateSaleId()
 * Convenience wrapper — generates a Sale ID.
 */
function generateSaleId() {
  return generateUniqueId('Sale_ID_Prefix', 'Last_Sale_Seq');
}

/**
 * generateExpenseId()
 * Convenience wrapper — generates an Expense ID.
 */
function generateExpenseId() {
  return generateUniqueId('Expense_ID_Prefix', 'Last_Expense_Seq');
}


// ════════════════════════════════════════════════════════════
//  2. TIMESTAMP HELPERS
// ════════════════════════════════════════════════════════════

/**
 * getTimestamp()
 * ─────────────────────────────────────────────────────────────
 * Returns current date-time as a formatted string.
 * Format is driven by the Settings sheet — no hardcoding.
 *
 * @returns {string} e.g. "25/01/2025 14:35:22"
 */
function getTimestamp() {
  const tz     = getSetting('Timezone') || 'Asia/Kolkata';
  const now    = new Date();
  const format = 'dd/MM/yyyy HH:mm:ss';   // Always store full datetime in data

  return Utilities.formatDate(now, tz, format);
}

/**
 * getDateOnly()
 * ─────────────────────────────────────────────────────────────
 * Returns current date only, using the clinic's date format.
 *
 * @returns {string} e.g. "25/01/2025"
 */
function getDateOnly() {
  const tz  = getSetting('Timezone') || 'Asia/Kolkata';
  const fmt = getSetting('Date_Format') || 'DD/MM/YYYY';

  // Translate Settings format to Apps Script format
  const appsScriptFmt = fmt
    .replace('YYYY', 'yyyy')
    .replace('MM',   'MM')
    .replace('DD',   'dd');

  return Utilities.formatDate(new Date(), tz, appsScriptFmt);
}

/**
 * parseDate(dateString)
 * ─────────────────────────────────────────────────────────────
 * Safely parses a date string into a JS Date object.
 * Falls back to current date if parsing fails.
 *
 * @param  {string} dateString
 * @returns {Date}
 */
function parseDate(dateString) {
  const parsed = new Date(dateString);
  return isNaN(parsed.getTime()) ? new Date() : parsed;
}


// ════════════════════════════════════════════════════════════
//  3. DATA VALIDATION HELPERS
// ════════════════════════════════════════════════════════════

/**
 * isEmptyOrNull(value)
 * Returns true if value is null, undefined, or empty string.
 */
function isEmptyOrNull(value) {
  return value === null || value === undefined || String(value).trim() === '';
}

/**
 * isValidEmail(email)
 * Basic RFC 5322-lite email validation.
 * @returns {boolean}
 */
function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(String(email).trim());
}

/**
 * isValidPhone(phone)
 * Validates phone numbers — allows digits, spaces, +, -, ()
 * Minimum 7 digits.
 * @returns {boolean}
 */
function isValidPhone(phone) {
  const digits = String(phone).replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

/**
 * isPositiveNumber(value)
 * Returns true if value is a finite number > 0.
 */
function isPositiveNumber(value) {
  return typeof value === 'number'
    ? isFinite(value) && value > 0
    : isFinite(parseFloat(value)) && parseFloat(value) > 0;
}

/**
 * validateRequiredFields(dataObj, requiredKeys)
 * ─────────────────────────────────────────────────────────────
 * Checks that all required keys are non-empty in a data object.
 * Returns { valid: bool, missing: string[] }
 *
 * @param  {Object}   dataObj      - Data object to validate
 * @param  {string[]} requiredKeys - List of required keys
 * @returns {{ valid: boolean, missing: string[] }}
 */
function validateRequiredFields(dataObj, requiredKeys) {
  const missing = requiredKeys.filter(k => isEmptyOrNull(dataObj[k]));
  return {
    valid  : missing.length === 0,
    missing: missing
  };
}

/**
 * sanitizeText(text)
 * ─────────────────────────────────────────────────────────────
 * Trims and normalizes whitespace in a string.
 * Prevents accidental double-spaces and leading/trailing spaces.
 */
function sanitizeText(text) {
  return String(text || '').trim().replace(/\s+/g, ' ');
}

/**
 * sanitizeNumber(value, fallback)
 * Converts to float; returns fallback if NaN.
 */
function sanitizeNumber(value, fallback = 0) {
  const n = parseFloat(value);
  return isNaN(n) ? fallback : n;
}


// ════════════════════════════════════════════════════════════
//  4. SHEET HELPER UTILITIES
// ════════════════════════════════════════════════════════════

/**
 * getOrCreateSheet(name)
 * ─────────────────────────────────────────────────────────────
 * Returns an existing sheet by name, or creates it if absent.
 *
 * @param  {string} name - Sheet name
 * @returns {GoogleAppsScript.Spreadsheet.Sheet}
 */
function getOrCreateSheet(name) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  let   sheet = ss.getSheetByName(name);

  if (!sheet) {
    sheet = ss.insertSheet(name);
    _log('INFO', 'getOrCreateSheet', `Created new sheet: ${name}`);
  }

  return sheet;
}

/**
 * setSheetHeaders(sheet, headers, colorHex)
 * ─────────────────────────────────────────────────────────────
 * Writes a styled header row to a sheet.
 * Color defaults to clinic Primary_Color from Settings.
 *
 * @param {Sheet}    sheet    - Target sheet
 * @param {string[]} headers  - Array of column header names
 * @param {string}   colorHex - Background color (optional)
 */
function setSheetHeaders(sheet, headers, colorHex) {
  const bgColor  = colorHex || getSetting('Primary_Color') || '#1a73e8';
  const range    = sheet.getRange(1, 1, 1, headers.length);

  range.setValues([headers]);
  range.setFontWeight('bold');
  range.setBackground(bgColor);
  range.setFontColor('#ffffff');
  range.setHorizontalAlignment('center');

  sheet.setFrozenRows(1);
}

/**
 * appendRowToSheet(sheetName, rowData)
 * ─────────────────────────────────────────────────────────────
 * Appends a data row to the named sheet.
 * Returns the row number where data was written.
 *
 * @param  {string}  sheetName - Target sheet name
 * @param  {Array}   rowData   - Array of values to append
 * @returns {number} Row number written
 */
function appendRowToSheet(sheetName, rowData) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(sheetName);

  if (!sheet) {
    throw new Error(`Sheet "${sheetName}" not found.`);
  }

  sheet.appendRow(rowData);
  const rowNum = sheet.getLastRow();

  _log('INFO', 'appendRowToSheet',
    `Row ${rowNum} written to [${sheetName}]`);

  return rowNum;
}

/**
 * getSheetData(sheetName)
 * ─────────────────────────────────────────────────────────────
 * Returns all data rows (excluding header) as array of objects,
 * using column 1 as the key source (from header row).
 *
 * @param  {string} sheetName
 * @returns {Object[]} Array of row objects
 */
function getSheetData(sheetName) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(sheetName);

  if (!sheet || sheet.getLastRow() < 2) return [];

  const [headerRow, ...dataRows] = sheet.getDataRange().getValues();

  return dataRows.map(row => {
    const obj = {};
    headerRow.forEach((col, idx) => {
      obj[col] = row[idx];
    });
    return obj;
  });
}

/**
 * _applyAlternateRowColors(sheet, startRow, numRows, color1, color2)
 * ─────────────────────────────────────────────────────────────
 * Applies zebra striping to a range of rows.
 */
function _applyAlternateRowColors(sheet, startRow, numRows, color1, color2) {
  const lastCol = sheet.getLastColumn() || 10;

  for (let i = 0; i < numRows; i++) {
    const row   = startRow + i;
    const color = (i % 2 === 0) ? color1 : color2;
    sheet.getRange(row, 1, 1, lastCol).setBackground(color);
  }
}

/**
 * clearSheetData(sheetName)
 * Clears all data rows (keeps header row).
 * USE WITH CAUTION.
 *
 * @param {string} sheetName
 */
function clearSheetData(sheetName) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(sheetName);

  if (!sheet || sheet.getLastRow() < 2) return;

  sheet.deleteRows(2, sheet.getLastRow() - 1);
  _log('WARN', 'clearSheetData', `All data cleared from [${sheetName}]`);
}
