// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Settings.gs
//  Description : getSettings() — single source of truth for
//                all clinic configuration values.
//                Nothing is hardcoded. Everything comes from
//                the Settings sheet.
// ============================================================


/**
 * getSettings()
 * ─────────────────────────────────────────────────────────────
 * Reads the Settings sheet and returns a plain JS object.
 * Key   = Column A (Setting_Key)
 * Value = Column B (Setting_Value)
 *
 * Usage anywhere in the project:
 *   const s = getSettings();
 *   const name = s['Clinic_Name'];
 *
 * @returns {Object} key-value map of all settings
 */
function getSettings() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAMES.SETTINGS);

  if (!sheet) {
    throw new Error(
      'Settings sheet not found. Please run "Initialize System" first.'
    );
  }

  const data     = sheet.getDataRange().getValues();
  const settings = {};

  // Row 0 = header; skip it
  for (let i = 1; i < data.length; i++) {
    const key   = String(data[i][0]).trim();
    const value = data[i][1];

    if (key) {
      settings[key] = value;
    }
  }

  return settings;
}


/**
 * getSetting(key)
 * ─────────────────────────────────────────────────────────────
 * Convenience wrapper to fetch a single setting value.
 *
 * @param  {string} key - One of the SETTINGS_KEYS constants
 * @returns {string|number|boolean} The setting value
 */
function getSetting(key) {
  const settings = getSettings();
  return settings[key] !== undefined ? settings[key] : null;
}


/**
 * updateSetting(key, value)
 * ─────────────────────────────────────────────────────────────
 * Programmatically updates a single setting value in the sheet.
 * Useful for system-level writes (e.g., storing generated IDs).
 *
 * @param {string} key   - Setting key (Column A)
 * @param {*}      value - New value to write (Column B)
 * @returns {boolean} true if updated, false if key not found
 */
function updateSetting(key, value) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAMES.SETTINGS);

  if (!sheet) return false;

  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === key) {
      sheet.getRange(i + 1, 2).setValue(value);
      _log('INFO', 'updateSetting', `Updated "${key}" → "${value}"`);
      return true;
    }
  }

  _log('WARN', 'updateSetting', `Key "${key}" not found in Settings sheet.`);
  return false;
}


// ─── SETTINGS SHEET BUILDER ──────────────────────────────────
/**
 * _createSettingsSheet()
 * ─────────────────────────────────────────────────────────────
 * Creates the Settings sheet with all required rows.
 * If the sheet already exists, it is preserved (not overwritten).
 */
function _createSettingsSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAMES.SETTINGS);

  if (sheet) {
    _log('INFO', '_createSettingsSheet', 'Settings sheet already exists. Skipped.');
    return;
  }

  sheet = ss.insertSheet(SHEET_NAMES.SETTINGS, 0); // First tab

  // ── Header row ─────────────────────────────────────────────
  const headers = ['Setting_Key', 'Setting_Value', 'Description'];
  sheet.getRange(1, 1, 1, headers.length)
    .setValues([headers])
    .setFontWeight('bold')
    .setBackground('#1a73e8')
    .setFontColor('#ffffff');

  // ── Default settings rows ──────────────────────────────────
  const defaults = [
    // [ Key,                  Default Value,             Description ]
    ['Clinic_Name',        'My Clinic',                  'Full name of the clinic'],
    ['Logo_URL',           '',                           'Public URL of the clinic logo image'],
    ['Primary_Color',      '#1a73e8',                   'Hex color for primary UI elements'],
    ['Secondary_Color',    '#f1f3f4',                   'Hex color for secondary UI elements'],
    ['Phone_Number',       '+91 00000 00000',            'Primary contact number'],
    ['Address',            '123 Main St, City, State',  'Clinic address'],
    ['Currency',           '₹',                          'Currency symbol (e.g. ₹, $, €)'],
    ['Date_Format',        'DD/MM/YYYY',                 'Date display format'],
    ['Timezone',           'Asia/Kolkata',               'Timezone for timestamps (IANA format)'],
    ['Admin_Email',        '',                           'Admin email for notifications'],
    ['Patient_ID_Prefix',  'PAT',                        'Prefix for Patient IDs (e.g. PAT-0001)'],
    ['Appt_ID_Prefix',     'APT',                        'Prefix for Appointment IDs'],
    ['Sale_ID_Prefix',     'SAL',                        'Prefix for Sale IDs'],
    ['Expense_ID_Prefix',  'EXP',                        'Prefix for Expense IDs'],
    ['Last_Patient_Seq',   0,                            'DO NOT EDIT — auto-managed sequence counter'],
    ['Last_Appt_Seq',      0,                            'DO NOT EDIT — auto-managed sequence counter'],
    ['Last_Sale_Seq',      0,                            'DO NOT EDIT — auto-managed sequence counter'],
    ['Last_Expense_Seq',   0,                            'DO NOT EDIT — auto-managed sequence counter'],
    ['System_Version',     SYSTEM_VERSION,               'Installed system version']
  ];

  sheet.getRange(2, 1, defaults.length, 3).setValues(defaults);

  // ── Column widths ──────────────────────────────────────────
  sheet.setColumnWidth(1, 200);
  sheet.setColumnWidth(2, 250);
  sheet.setColumnWidth(3, 350);

  // ── Protect the Key column (A) from accidental edits ──────
  const protection = sheet.getRange('A:A').protect();
  protection.setDescription('Setting keys — do not rename');
  protection.setWarningOnly(true);

  // ── Alternate row shading ──────────────────────────────────
  _applyAlternateRowColors(sheet, 2, defaults.length, '#e8f0fe', '#ffffff');

  // ── Freeze header ─────────────────────────────────────────
  sheet.setFrozenRows(1);

  _log('INFO', '_createSettingsSheet', 'Settings sheet created with defaults.');
}
