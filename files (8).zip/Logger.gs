// ============================================================
//  UNIVERSAL CLINIC MANAGEMENT SYSTEM
//  File        : Logger.gs
//  Description : Structured logging system.
//                Writes timestamped entries to System_Log sheet.
//                Supports INFO / WARN / ERROR levels.
//                Keeps log trimmed to last 1000 entries.
// ============================================================

const LOG_MAX_ROWS   = 1000;   // Max log entries to retain
const LOG_TRIM_BATCH = 100;    // Delete this many when trimming

/**
 * _log(level, source, message)
 * ─────────────────────────────────────────────────────────────
 * Core logging function used throughout the system.
 * Call this from any .gs file — it is globally accessible.
 *
 * @param {'INFO'|'WARN'|'ERROR'} level   - Severity level
 * @param {string}                source  - Function or module name
 * @param {string}                message - Log message
 */
function _log(level, source, message) {
  // Always echo to native Apps Script logger (visible in Executions)
  Logger.log(`[${level}] [${source}] ${message}`);

  try {
    const ss    = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAMES.LOG);

    if (!sheet) return; // Log sheet not created yet (during init)

    const timestamp = getTimestamp();
    const userEmail = Session.getActiveUser().getEmail() || 'system';

    sheet.appendRow([timestamp, level, source, message, userEmail]);

    // ── Auto-trim: prevent runaway log growth ─────────────────
    const rowCount = sheet.getLastRow();
    if (rowCount > LOG_MAX_ROWS + 1) {  // +1 for header
      sheet.deleteRows(2, LOG_TRIM_BATCH);
    }

  } catch (e) {
    // Silent fail — logging should never break the main flow
    Logger.log('[Logger] Could not write to log sheet: ' + e.message);
  }
}


// ─── LOG SHEET BUILDER ───────────────────────────────────────
/**
 * _createLogSheet()
 * Creates the System_Log sheet if it doesn't exist.
 */
function _createLogSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (ss.getSheetByName(SHEET_NAMES.LOG)) {
    Logger.log('[_createLogSheet] Log sheet already exists. Skipped.');
    return;
  }

  const sheet = ss.insertSheet(SHEET_NAMES.LOG);

  const headers = ['Timestamp', 'Level', 'Source', 'Message', 'User'];
  setSheetHeaders(sheet, headers, '#37474f'); // Dark charcoal header

  // Column widths
  sheet.setColumnWidth(1, 170); // Timestamp
  sheet.setColumnWidth(2, 70);  // Level
  sheet.setColumnWidth(3, 180); // Source
  sheet.setColumnWidth(4, 450); // Message
  sheet.setColumnWidth(5, 200); // User

  // Conditional formatting: color by level
  const rules = [];
  const range  = sheet.getRange('B:B');

  rules.push(
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('ERROR')
      .setBackground('#fce8e6')
      .setFontColor('#c5221f')
      .setRanges([sheet.getRange('A:E')])
      .build()
  );

  rules.push(
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('WARN')
      .setBackground('#fef7e0')
      .setFontColor('#f29900')
      .setRanges([sheet.getRange('A:E')])
      .build()
  );

  rules.push(
    SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('INFO')
      .setBackground('#e6f4ea')
      .setFontColor('#137333')
      .setRanges([sheet.getRange('A:E')])
      .build()
  );

  sheet.setConditionalFormatRules(rules);

  Logger.log('[_createLogSheet] System_Log sheet created.');
}


// ─── LOG SEARCH / EXPORT ─────────────────────────────────────
/**
 * getLogsByLevel(level)
 * ─────────────────────────────────────────────────────────────
 * Returns all log entries for a specific level.
 * Useful for building error-report dashboards later.
 *
 * @param  {'INFO'|'WARN'|'ERROR'} level
 * @returns {Object[]} Filtered log rows as objects
 */
function getLogsByLevel(level) {
  const all = getSheetData(SHEET_NAMES.LOG);
  return all.filter(row => row['Level'] === level);
}

/**
 * clearSystemLog()
 * ─────────────────────────────────────────────────────────────
 * Clears all log entries. Keeps header. Admin-only action.
 */
function clearSystemLog() {
  const ui = SpreadsheetApp.getUi();
  const confirm = ui.alert(
    '⚠️ Clear System Log',
    'This will permanently delete all log entries.\nAre you sure?',
    ui.ButtonSet.YES_NO
  );

  if (confirm !== ui.Button.YES) return;

  clearSheetData(SHEET_NAMES.LOG);
  _log('WARN', 'clearSystemLog', 'System log was manually cleared by admin.');
  ui.alert('Log cleared successfully.');
}
