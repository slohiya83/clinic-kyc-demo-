# 🏥 Universal Clinic Management System
## Base System — Setup & Architecture Guide
### Version 1.0.0

---

## 📋 TABLE OF CONTENTS
1. [System Overview](#system-overview)
2. [File Structure](#file-structure)
3. [Sheet Structure (Column-by-Column)](#sheet-structure)
4. [Step-by-Step Setup Instructions](#setup-instructions)
5. [Settings Sheet Reference](#settings-reference)
6. [Architecture Decisions](#architecture)
7. [Customization Guide (Per Client)](#customization)
8. [Development Roadmap](#roadmap)

---

## 1. SYSTEM OVERVIEW <a name="system-overview"></a>

This is a **Universal, Reusable Clinic Management System** built on Google Sheets + Apps Script.

### Core Design Principles
| Principle | Implementation |
|---|---|
| **Zero Hardcoding** | Every brand value is read from the Settings sheet |
| **Modular** | Each module is a separate `.gs` file |
| **Scalable** | Add new features without touching existing code |
| **Multi-Client Ready** | Deploy once, customize via Settings only |
| **Audit-Ready** | Every action is logged with timestamp + user |

### How Multi-Client Works
```
Master Template (this system)
        │
        ├── Client A: "Sharma Dental Clinic"
        │       └── Settings sheet: Clinic_Name = "Sharma Dental"
        │
        ├── Client B: "Sunrise Eye Care"
        │       └── Settings sheet: Clinic_Name = "Sunrise Eye Care"
        │
        └── Client C: "CityMed Hospital"
                └── Settings sheet: Clinic_Name = "CityMed Hospital"

No code changes needed between clients. Only Settings changes.
```

---

## 2. FILE STRUCTURE <a name="file-structure"></a>

```
Google Apps Script Project
│
├── Code.gs           ← ENTRY POINT: Menu, onOpen(), initSystem()
├── Settings.gs       ← getSettings(), getSetting(), updateSetting()
├── Utilities.gs      ← ID generator, timestamps, validators, sheet helpers
├── Logger.gs         ← _log() system, log sheet builder
├── SheetBuilders.gs  ← Creates all 6 sheets with proper structure
└── Modules.gs        ← Placeholder stubs: handleKYC(), handleSales(), etc.
```

### File Load Order (Apps Script auto-sorts alphabetically)
`Code.gs → Logger.gs → Modules.gs → Settings.gs → SheetBuilders.gs → Utilities.gs`

> **Note:** All functions are global in Apps Script, so load order doesn't matter for function calls.

---

## 3. SHEET STRUCTURE <a name="sheet-structure"></a>

### 📊 Settings Sheet
| # | Column A (Key) | Column B (Value) | Column C (Description) |
|---|---|---|---|
| 1 | **Header** | **Header** | **Header** |
| 2 | Clinic_Name | My Clinic | Full clinic name |
| 3 | Logo_URL | *(empty)* | Public image URL |
| 4 | Primary_Color | #1a73e8 | Hex for primary UI |
| 5 | Secondary_Color | #f1f3f4 | Hex for secondary UI |
| 6 | Phone_Number | +91 00000 00000 | Main contact |
| 7 | Address | 123 Main St... | Clinic address |
| 8 | Currency | ₹ | Symbol: ₹ / $ / € |
| 9 | Date_Format | DD/MM/YYYY | Display format |
| 10 | Timezone | Asia/Kolkata | IANA timezone |
| 11 | Admin_Email | *(empty)* | For notifications |
| 12 | Patient_ID_Prefix | PAT | e.g. PAT-2025-0001 |
| 13 | Appt_ID_Prefix | APT | e.g. APT-2025-0001 |
| 14 | Sale_ID_Prefix | SAL | e.g. SAL-2025-0001 |
| 15 | Expense_ID_Prefix | EXP | e.g. EXP-2025-0001 |
| 16 | Last_Patient_Seq | 0 | Auto-managed counter |
| 17 | Last_Appt_Seq | 0 | Auto-managed counter |
| 18 | Last_Sale_Seq | 0 | Auto-managed counter |
| 19 | Last_Expense_Seq | 0 | Auto-managed counter |
| 20 | System_Version | 1.0.0 | Installed version |

---

### 📋 KYC_Data Sheet (17 Columns)
| Col | Header | Type | Notes |
|---|---|---|---|
| A | Patient_ID | Text | Auto: PAT-2025-0001 |
| B | Full_Name | Text | Required |
| C | Date_of_Birth | Date | DD/MM/YYYY |
| D | Age | Number | Auto-calculated |
| E | Gender | Dropdown | Male/Female/Other |
| F | Phone | Text | Required |
| G | Email | Email | Optional |
| H | Address | Text | Full address |
| I | Blood_Group | Dropdown | A+/A-/B+/B-... |
| J | Emergency_Contact | Text | Name + Phone |
| K | Medical_History | Text | Free text |
| L | Allergies | Text | Free text |
| M | Insurance_No | Text | Optional |
| N | Referred_By | Text | Source tracking |
| O | Created_At | Timestamp | Auto |
| P | Updated_At | Timestamp | Auto on edit |
| Q | Status | Dropdown | Active/Inactive |

---

### 📅 Appointments Sheet (15 Columns)
| Col | Header | Type | Notes |
|---|---|---|---|
| A | Appt_ID | Text | Auto: APT-2025-0001 |
| B | Patient_ID | Text | Links to KYC_Data |
| C | Patient_Name | Text | Auto-filled |
| D | Doctor | Text | Treating doctor |
| E | Appt_Date | Date | |
| F | Time_Slot | Text | e.g. "10:00 AM" |
| G | Appt_Type | Dropdown | Consultation/Follow-Up... |
| H | Status | Dropdown | Scheduled/Completed... |
| I | Diagnosis | Text | Free text |
| J | Prescription | Text | Free text |
| K | Consultation_Fee | Number | Currency |
| L | Notes | Text | Free text |
| M | Follow_Up_Date | Date | Optional |
| N | Created_At | Timestamp | Auto |
| O | Updated_At | Timestamp | Auto |

---

### 💰 Sales Sheet (16 Columns)
| Col | Header | Type | Notes |
|---|---|---|---|
| A | Sale_ID | Text | Auto: SAL-2025-0001 |
| B | Sale_Date | Date | |
| C | Patient_ID | Text | Links to KYC_Data |
| D | Patient_Name | Text | Auto-filled |
| E | Item_Type | Dropdown | Medicine/Service/Lab... |
| F | Item_Name | Text | |
| G | Quantity | Number | |
| H | Unit_Price | Number | |
| I | Discount_Pct | Number | % |
| J | Discount_Amt | Formula | = G×H×I/100 |
| K | Total_Amount | Formula | = G×H - J |
| L | Payment_Mode | Dropdown | Cash/Card/UPI... |
| M | Payment_Status | Dropdown | Paid/Pending... |
| N | Invoice_No | Text | |
| O | Notes | Text | |
| P | Created_At | Timestamp | Auto |

---

### 🧾 Expenses Sheet (14 Columns)
| Col | Header | Type | Notes |
|---|---|---|---|
| A | Expense_ID | Text | Auto: EXP-2025-0001 |
| B | Expense_Date | Date | |
| C | Category | Dropdown | Salary/Supplies/Utilities... |
| D | Sub_Category | Text | |
| E | Description | Text | |
| F | Amount | Number | Currency |
| G | Paid_To | Text | Vendor/Employee name |
| H | Payment_Mode | Dropdown | Cash/Card/UPI... |
| I | Receipt_No | Text | |
| J | Approved_By | Text | |
| K | Is_Recurring | Dropdown | Yes/No |
| L | Recur_Period | Text | Monthly/Weekly/Annually |
| M | Notes | Text | |
| N | Created_At | Timestamp | Auto |

---

### 📊 Dashboard_Data Sheet (6 Columns)
| Col | Header | Notes |
|---|---|---|
| A | Metric | KPI name |
| B | Current_Period | Current value |
| C | Previous_Period | Previous value |
| D | Change_Pct | % change |
| E | Period_Label | e.g. "January 2025" |
| F | Last_Updated | Auto-timestamp |

**Pre-loaded KPI rows:**
- Total Revenue | Total Expenses | Net Profit | Profit Margin %
- Total Patients | New Patients | Total Appointments
- Completed Appointments | Cancellation Rate %
- Avg Revenue per Patient | Top Expense Category | Outstanding Payments

---

### 📜 System_Log Sheet (5 Columns)
| Col | Header | Notes |
|---|---|---|
| A | Timestamp | Auto |
| B | Level | INFO / WARN / ERROR |
| C | Source | Function name |
| D | Message | Log message |
| E | User | Google account email |

Color-coded: 🟢 INFO (green) | 🟡 WARN (yellow) | 🔴 ERROR (red)
Auto-trims at 1,000 rows.

---

## 4. STEP-BY-STEP SETUP INSTRUCTIONS <a name="setup-instructions"></a>

### Prerequisites
- A Google Account
- Access to Google Sheets + Google Drive

---

### Step 1 — Create the Spreadsheet
```
1. Go to https://sheets.google.com
2. Click "+ Blank spreadsheet"
3. Rename it: "Clinic Management System — [Client Name]"
```

### Step 2 — Open Apps Script Editor
```
1. In your spreadsheet, click: Extensions → Apps Script
2. The script editor opens in a new tab
3. Delete the default "myFunction()" placeholder code
```

### Step 3 — Create the Script Files
Create the following files in the Apps Script editor (use the "+" icon → Script):

```
File 1: Code.gs        → paste Code.gs content
File 2: Settings.gs    → paste Settings.gs content
File 3: Utilities.gs   → paste Utilities.gs content
File 4: Logger.gs      → paste Logger.gs content
File 5: SheetBuilders.gs → paste SheetBuilders.gs content
File 6: Modules.gs     → paste Modules.gs content
```

> ⚠️ **Important:** The default file is called "Code.gs" — use it for Code.gs content. Create the other 5 files with the "+" button.

### Step 4 — Save the Project
```
1. Click the floppy disk icon (or Ctrl+S / Cmd+S)
2. Name the project: "Clinic Management System"
3. Click OK
```

### Step 5 — Run Initialization
```
1. Go back to your Google Spreadsheet
2. Reload the page (F5 or Cmd+R)
3. Wait for the top menu to load
4. You will see: "🏥 Clinic System" in the menu bar
5. Click: 🏥 Clinic System → ✅ Initialize System
6. Grant permissions when Google asks (first-time only)
7. Click "Allow" to authorize the script
8. Run Initialize System again after granting permissions
```

### Step 6 — Verify Setup
After initialization, you should see 7 new sheets:
```
✅ Settings
✅ KYC_Data
✅ Appointments
✅ Sales
✅ Expenses
✅ Dashboard_Data
✅ System_Log
```

### Step 7 — Configure for Your Client
```
1. Click the "Settings" tab
2. Update the following rows:
   • Clinic_Name    → e.g. "Sharma Dental Clinic"
   • Logo_URL       → Paste a public image URL
   • Primary_Color  → e.g. "#0d47a1" (dark blue)
   • Phone_Number   → Clinic's contact number
   • Address        → Full clinic address
   • Currency       → ₹ or $ or € as needed
   • Timezone       → e.g. "Asia/Kolkata" or "America/New_York"
   • Admin_Email    → Admin's email for notifications
```

---

## 5. SETTINGS SHEET REFERENCE <a name="settings-reference"></a>

### Complete IANA Timezone List (Common)
| Region | Timezone Value |
|---|---|
| India | Asia/Kolkata |
| UAE | Asia/Dubai |
| UK | Europe/London |
| USA (East) | America/New_York |
| USA (West) | America/Los_Angeles |
| Singapore | Asia/Singapore |
| Australia | Australia/Sydney |

### Color Suggestions
| Theme | Primary | Secondary |
|---|---|---|
| Medical Blue | #1a73e8 | #e8f0fe |
| Health Green | #2e7d32 | #e8f5e9 |
| Trust Navy | #0d47a1 | #e3f2fd |
| Care Purple | #4a148c | #f3e5f5 |

---

## 6. ARCHITECTURE DECISIONS <a name="architecture"></a>

### Why Google Sheets + Apps Script?
```
✅ Zero infrastructure cost
✅ No server to maintain
✅ Familiar interface for clinic staff
✅ Built-in data persistence
✅ Google Workspace integration (Gmail, Drive, Calendar)
✅ Offline-capable (Google Sheets mobile app)
✅ Audit trail via Sheet history
```

### Settings-Driven Design Pattern
```javascript
// ❌ WRONG — Hardcoded (breaks multi-client)
function sendEmail() {
  const clinicName = "Sharma Dental";  // Hardcoded!
}

// ✅ CORRECT — Settings-driven (works for any client)
function sendEmail() {
  const clinicName = getSetting('Clinic_Name');  // Dynamic!
}
```

### ID Generation Strategy
```
Format: PREFIX-YEAR-SEQUENCE
Example: PAT-2025-0001

Benefits:
• Human-readable (staff can reference without tech knowledge)
• Year-segregated (easy to identify records by year)
• Sequential (easy auditing and sorting)
• Prefix-configurable per client via Settings
```

### Module Isolation
```
Each module (KYC, Appointments, Sales, Expenses) is:
• Independent — can be developed/tested separately
• Self-contained — reads config only from Settings
• Non-breaking — adding a module never breaks others
• Replaceable — swap implementation without changing API
```

---

## 7. CUSTOMIZATION GUIDE (PER CLIENT) <a name="customization"></a>

### To Deploy for a New Client
```
1. Make a copy of the master Google Spreadsheet
   File → Make a copy → Rename with client name

2. Open the Settings sheet
   Update: Clinic_Name, Logo_URL, Colors, Phone, Address

3. Optional: Change ID prefixes
   e.g. Patient_ID_Prefix = "DEN" for dental clinic
        Patient_ID_Prefix = "EYE" for eye clinic

4. Run: 🏥 Clinic System → ✅ Initialize System
   (Existing sheets are preserved; new ones are created)

5. Share the spreadsheet with clinic staff
   File → Share → Add people
```

### No Code Changes Required
```
Scenario: Client wants ₹ currency vs $ currency
Solution: Change Settings → Currency from "$" to "₹"

Scenario: Client wants "DEN" prefix for patient IDs
Solution: Change Settings → Patient_ID_Prefix to "DEN"

Scenario: Client is in UAE timezone
Solution: Change Settings → Timezone to "Asia/Dubai"
```

---

## 8. DEVELOPMENT ROADMAP <a name="roadmap"></a>

### ✅ Phase 1 (COMPLETE) — Base System
- [x] Sheet structure (7 sheets)
- [x] Settings-driven architecture
- [x] Unique ID generator
- [x] Timestamp utilities
- [x] Data validators
- [x] Logging system
- [x] Module stubs
- [x] Clinic System menu

### 🔄 Phase 2 — KYC / Patient Module
- [ ] Patient registration sidebar form (HTML)
- [ ] Patient search & lookup
- [ ] Patient edit flow
- [ ] Age auto-calculation from DOB
- [ ] Duplicate phone number detection

### 🔄 Phase 3 — Appointments Module
- [ ] Appointment booking form
- [ ] Today's schedule view (sidebar)
- [ ] Conflict detection (double-booking)
- [ ] Status update workflow
- [ ] Follow-up reminder trigger

### 🔄 Phase 4 — Sales & Expenses Module
- [ ] Sales entry form with live total calculation
- [ ] Invoice PDF generation (Google Docs template)
- [ ] Expense entry form
- [ ] Recurring expense auto-entry (Time trigger)
- [ ] Payment status tracker

### 🔄 Phase 5 — Profit & Finance Engine
- [ ] Automated P&L calculation
- [ ] Monthly/quarterly summaries
- [ ] Category-wise expense breakdown
- [ ] Tax estimation (configurable %)
- [ ] Finance PDF report

### 🔄 Phase 6 — Dashboard
- [ ] HTML sidebar dashboard with live KPIs
- [ ] Charts (Google Charts API)
- [ ] Patient growth metrics
- [ ] Revenue trends
- [ ] Dashboard PDF export

### 🔄 Phase 7 — Advanced Features
- [ ] Email notification system (Gmail API)
- [ ] WhatsApp/SMS integration (Twilio / Msg91)
- [ ] Google Calendar sync for appointments
- [ ] Google Drive integration for receipts/files
- [ ] Multi-doctor support
- [ ] Role-based access (Admin / Receptionist / Doctor)

---

## QUICK REFERENCE — Key Functions

| Function | File | Purpose |
|---|---|---|
| `getSettings()` | Settings.gs | Get all settings as object |
| `getSetting(key)` | Settings.gs | Get single setting value |
| `updateSetting(key, val)` | Settings.gs | Write a value to Settings |
| `generatePatientId()` | Utilities.gs | Auto-increment patient ID |
| `generateAppointmentId()` | Utilities.gs | Auto-increment appt ID |
| `generateSaleId()` | Utilities.gs | Auto-increment sale ID |
| `generateExpenseId()` | Utilities.gs | Auto-increment expense ID |
| `getTimestamp()` | Utilities.gs | Current datetime string |
| `getDateOnly()` | Utilities.gs | Current date string |
| `validateRequiredFields()` | Utilities.gs | Form validation |
| `appendRowToSheet()` | Utilities.gs | Write data to any sheet |
| `getSheetData()` | Utilities.gs | Read sheet as objects |
| `_log(level, src, msg)` | Logger.gs | System log entry |
| `initSystem()` | Code.gs | Full system setup |
| `onOpen()` | Code.gs | Builds the menu |

---

*Universal Clinic Management System — Base v1.0.0*
*Ready for Phase 2 development on instruction.*
